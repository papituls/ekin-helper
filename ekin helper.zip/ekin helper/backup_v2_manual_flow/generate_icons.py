"""
generate_icons.py — Buat icon PNG ekstensi secara programatik
Jalankan: python generate_icons.py
Memerlukan: Pillow (pip install pillow)
"""

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("Pillow tidak ada. Menggunakan fallback minimal PNG.")
    Image = None

import os
import struct
import zlib

ICON_DIR = os.path.join(os.path.dirname(__file__), 'icons')
os.makedirs(ICON_DIR, exist_ok=True)

SIZES = [16, 48, 128]

def make_minimal_png(size):
    """Buat PNG minimal 1x1 yang di-scale, tanpa Pillow."""
    # Header PNG
    def png_chunk(name, data):
        c = zlib.crc32(name + data) & 0xffffffff
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)

    # Background: biru Google #1a73e8 = (26, 115, 232)
    r, g, b = 26, 115, 232

    # IHDR
    ihdr_data = struct.pack('>IIBBBBB', size, size, 8, 2, 0, 0, 0)
    ihdr = png_chunk(b'IHDR', ihdr_data)

    # IDAT: buat raw pixel data
    raw = b''
    for y in range(size):
        row = b'\x00'  # filter type = None
        for x in range(size):
            # Lingkaran biru dengan huruf "K" putih sederhana
            cx, cy = size / 2, size / 2
            dist = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
            radius = size / 2 - 1
            margin = size * 0.15
            if dist <= radius:
                # Area putih di tengah (huruf K sederhana)
                in_k = False
                # Batang vertikal K
                if (cx - size*0.1) <= x <= (cx - size*0.05) and (cy - size*0.25) <= y <= (cy + size*0.25):
                    in_k = True
                # Diag atas K
                if not in_k and (cx - size*0.05) <= x <= (cx + size*0.2):
                    slope = (y - (cy - size*0.05)) / max(x - (cx - size*0.05), 0.01)
                    if -1.5 <= slope <= -0.5 and cy - size*0.25 <= y <= cy:
                        in_k = True
                # Diag bawah K
                if not in_k and (cx - size*0.05) <= x <= (cx + size*0.2):
                    slope = (y - (cy + size*0.05)) / max(x - (cx - size*0.05), 0.01)
                    if 0.5 <= slope <= 1.5 and cy <= y <= cy + size*0.25:
                        in_k = True

                if in_k:
                    row += bytes([255, 255, 255])
                else:
                    row += bytes([r, g, b])
            else:
                row += bytes([240, 240, 245])  # background
        raw += row

    compressed = zlib.compress(raw)
    idat = png_chunk(b'IDAT', compressed)
    iend = png_chunk(b'IEND', b'')

    return b'\x89PNG\r\n\x1a\n' + ihdr + idat + iend

def make_icon_pillow(size):
    """Buat icon dengan Pillow — lebih bagus."""
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Background lingkaran biru
    padding = max(1, size // 16)
    draw.ellipse([padding, padding, size - padding, size - padding], fill=(26, 115, 232, 255))

    # Huruf "K" (kinerja) di tengah
    font_size = max(8, int(size * 0.55))
    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()

    text = "K"
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    tx = (size - tw) // 2 - bbox[0]
    ty = (size - th) // 2 - bbox[1]
    draw.text((tx, ty), text, fill=(255, 255, 255, 255), font=font)

    return img


def main():
    for sz in SIZES:
        filepath = os.path.join(ICON_DIR, f'icon{sz}.png')
        if Image:
            icon = make_icon_pillow(sz)
            icon.save(filepath, 'PNG')
            print(f'✅ {filepath} dibuat dengan Pillow ({sz}x{sz})')
        else:
            data = make_minimal_png(sz)
            with open(filepath, 'wb') as f:
                f.write(data)
            print(f'✅ {filepath} dibuat (minimal PNG, {sz}x{sz})')

if __name__ == '__main__':
    main()
