# 📋 Panduan Setup Google Cloud Console (Versi Praktis & Multi-User)
## (Hanya perlu dilakukan 1 kali oleh Anda, rekan kerja TIDAK perlu setup ini)

Dengan panduan ini, **Anda tidak perlu tahu atau mendaftarkan email rekan kerja satu per satu**. Semua rekan kerja yang menginstall ekstensi akan bisa langsung login dengan akun Google masing-masing.

---

### LANGKAH 1 — Buka Google Cloud Console
👉 https://console.cloud.google.com

Login dengan akun Google Anda (akun pribadi atau kantor).

---

### LANGKAH 2 — Buat Project Baru
1. Klik dropdown nama project di bagian atas (sebelah logo Google Cloud).
2. Klik **"New Project"**.
3. Isi:
   - Project name: `Asisten eKinerja BKN`
   - Location: biarkan default
4. Klik **"Create"**.
5. Tunggu notifikasi selesai → klik **"Select Project"** (pastikan project aktif di atas sudah berubah ke `Asisten eKinerja BKN`).

---

### LANGKAH 3 — Aktifkan Google Drive API
1. Buka menu navigasi kiri (garis tiga) → **"APIs & Services"** → **"Library"**.
2. Di kolom pencarian, ketik: `Google Drive API`.
3. Klik hasil **"Google Drive API"**.
4. Klik tombol biru **"Enable"**.
5. Tunggu beberapa detik hingga masuk ke dashboard API.

---

### LANGKAH 4 — Konfigurasi OAuth Consent Screen
1. Menu kiri → **"APIs & Services"** → **"OAuth consent screen"**.
2. Pilih **"External"** → klik **"Create"**.
3. **Step 1 (App information)**:
   - App name: `Asisten eKinerja BKN`
   - User support email: pilih email Anda
   - Developer contact information: isi email Anda
   - Klik **"Save and Continue"**.
4. **Step 2 (Scopes)**:
   - Tidak perlu diubah apa-apa. Langsung klik **"Save and Continue"**.
5. **Step 3 (Test users)**:
   - **TIDAK PERLU MENAMBAHKAN EMAIL**. Langsung klik **"Save and Continue"** (Skip).
6. **Step 4 (Summary)**:
   - Klik **"Back to Dashboard"**.

---

### LANGKAH 5 — Publikasikan App ("Publish App")
*(Langkah ini yang membuat rekan kerja Anda bisa langsung pakai tanpa Anda harus tahu email mereka)*

1. Masih di halaman **"OAuth consent screen"**.
2. Lihat kotak **"Publishing status"** di bagian atas (statusnya saat ini bertuliskan *Testing*).
3. Klik tombol **"PUBLISH APP"**.
4. Muncul jendela konfirmasi (Push to production) → klik **"Confirm"**.
5. Status sekarang berubah menjadi **"In production"**.
   > *Catatan: Ekstensi Anda tidak masuk ke pencarian publik Google/Chrome Web Store. Ini hanya membuka izin agar akun Google siapa pun yang memasang ekstensi bisa mengizinkan pembacaan file Drive-nya sendiri.*

---

### LANGKAH 6 — Cari Extension ID di Chrome Anda
1. Buka tab baru di browser Chrome → ketik: `chrome://extensions/`
2. Pastikan sakelar **"Developer mode"** di pojok kanan atas dalam posisi **AKTIF (ON)**.
3. Cari ekstensi **"Asisten e-Kinerja BKN"**.
4. Di bawah judul, terdapat baris **ID:** berupa 32 karakter huruf kecil (contoh: `abcdefghijklmnopqrstuvwxyzabcdef`).
5. **Salin (Copy) ID tersebut**.

---

### LANGKAH 7 — Buat OAuth Client ID (Pilih Tipe: Web application)
*(PENTING: Pilih "Web application", bukan "Chrome Extension", agar mendukung protokol login modern tanpa error)*

1. Kembali ke tab Google Cloud Console.
2. Menu kiri → **"APIs & Services"** → **"Credentials"**.
3. Di bagian atas, klik **"+ Create Credentials"** → pilih **"OAuth client ID"**.
4. Isi form:
   - Application type: pilih **"Web application"** (Aplikasi Web).
   - Name: `Asisten eKinerja`
   - Scroll ke bagian **"Authorized redirect URIs"** (URI Pengalihan yang Diizinkan).
   - Klik **"+ ADD URI"** lalu masukkan link berikut (persis, ada garis miring di ujung):
     ```text
     https://gnabgjenpfccbilfdabdcpmepieehiec.chromiumapp.org/
     ```
5. Klik **"Create"**.
6. Akan muncul popup berisi **Your Client ID**:
   ```text
   xxxxxxxxxxxx-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.apps.googleusercontent.com
   ```
7. **Salin Client ID tersebut**.

---

### LANGKAH 8 — Masukkan Client ID ke Ekstensi
1. Buka folder proyek di komputer Anda: `d:\RIYAN\PROJECT GAS\ekin helper\`
2. Buka file `manifest.json`.
3. Cari bagian `"oauth2"`:
   ```json
   "oauth2": {
     "client_id": "GANTI_DENGAN_CLIENT_ID_KAMU.apps.googleusercontent.com",
     "scopes": [
       "https://www.googleapis.com/auth/drive.readonly"
     ]
   }
   ```
4. Ganti teks `"GANTI_DENGAN_CLIENT_ID_KAMU.apps.googleusercontent.com"` dengan Client ID yang Anda dapatkan di Langkah 7.
5. Simpan file (`Ctrl + S`).
6. Buka kembali `chrome://extensions/` → klik ikon **🔄 Refresh / Reload** pada kartu ekstensi "Asisten e-Kinerja BKN".

---

### 🎉 Selesai! Cara Berbagi ke Rekan Kerja:
1. File ekstensi yang sudah diisi Client ID tinggal Anda zip/bagikan ke rekan kerja.
2. Rekan kerja mengekstrak folder dan memasangnya via `chrome://extensions/` -> **Load unpacked**.
3. Saat mereka klik **"Hubungkan Google Drive"** di ekstensi, browser Chrome mereka akan memunculkan popup konfirmasi akun Google masing-masing.
4. Klik **Allow / Lanjutkan**, dan selesai! Mereka bisa langsung membaca folder Drive masing-masing tanpa konfigurasi ulang Google Cloud.
