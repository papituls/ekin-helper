// background.js — Service Worker (Manifest V3) v2.0
// Mengelola Side Panel, OAuth, Drive API, dan routing pesan
import { getAuthToken, revokeToken, scanRootFolder, getFolderInfo, extractFolderId } from './drive-api.js';

// ──────────────────────────────────────────────
// 1. Buka Side Panel saat ikon ekstensi diklik
// ──────────────────────────────────────────────
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// ──────────────────────────────────────────────
// 2. Message Router
// ──────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;

  switch (type) {

    // ── Cek status login (apakah token tersedia) ──
    case 'AUTH_CHECK': {
      getAuthToken(false)
        .then((token) => sendResponse({ loggedIn: true, token }))
        .catch(() => sendResponse({ loggedIn: false }));
      return true;
    }

    // ── Login interaktif (minta izin ke user) ──
    case 'AUTH_LOGIN': {
      getAuthToken(true)
        .then((token) => sendResponse({ success: true, token }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;
    }

    // ── Logout (hapus token dari cache) ──
    case 'AUTH_LOGOUT': {
      getAuthToken(false)
        .then((token) => revokeToken(token))
        .then(() => sendResponse({ success: true }))
        .catch(() => sendResponse({ success: true })); // anggap sukses meski tidak ada token
      return true;
    }

    // ── Scan folder root Drive ──
    case 'DRIVE_SCAN': {
      handleDriveScan(payload, sender.tab?.id).then(sendResponse);
      return true;
    }

    // ── Info folder (validasi URL/ID yang diinput user) ──
    case 'DRIVE_FOLDER_INFO': {
      handleFolderInfo(payload).then(sendResponse);
      return true;
    }

    // ── Auto-fill ke e-Kinerja ──
    case 'FILL_BUKTI_DUKUNG':
    case 'FILL_REALISASI': {
      forwardToActiveTab(message, sendResponse);
      return true;
    }

    // ── Storage ops ──
    case 'GET_STORAGE': {
      chrome.storage.local.get(payload.keys, (data) => sendResponse({ data }));
      return true;
    }

    case 'SET_STORAGE': {
      chrome.storage.local.set(payload, () => sendResponse({ success: true }));
      return true;
    }

    default:
      break;
  }
});

// ──────────────────────────────────────────────
// 3. Handle Drive Scan (dengan progress streaming)
// ──────────────────────────────────────────────
async function handleDriveScan({ rootUrl, periods }, panelTabId) {
  const folderId = extractFolderId(rootUrl);
  if (!folderId) {
    return { error: 'URL atau ID folder tidak valid. Gunakan link dari address bar Google Drive.' };
  }

  let token;
  try {
    token = await getAuthToken(false);
  } catch {
    try {
      token = await getAuthToken(true);
    } catch (e) {
      return { error: `Gagal login: ${e.message}` };
    }
  }

  // Kirim progress ke side panel via storage (polling-based)
  const sendProgress = (msg) => {
    chrome.storage.local.set({ driveProgress: { msg, ts: Date.now() } });
  };

  try {
    sendProgress('🔐 Token diperoleh. Memulai scan...');

    // Info folder root
    const rootInfo = await getFolderInfo(folderId, token);
    if (!rootInfo.isFolder) {
      return { error: 'URL yang dimasukkan bukan folder. Pastikan link mengarah ke folder, bukan file.' };
    }

    sendProgress(`📁 Folder ditemukan: "${rootInfo.name}". Membaca struktur...`);

    const driveTree = await scanRootFolder(folderId, token, sendProgress, periods || null);

    // Simpan ke storage
    const { savedRoots } = await chrome.storage.local.get('savedRoots');
    const roots = savedRoots || {};
    roots[folderId] = {
      id: folderId,
      name: rootInfo.name,
      url: rootInfo.url,
      savedAt: new Date().toISOString(),
    };

    await chrome.storage.local.set({
      driveTree,
      currentRootId: folderId,
      currentRootName: rootInfo.name,
      savedRoots: roots,
      driveProgress: { msg: '✅ Scan selesai!', ts: Date.now(), done: true },
    });

    return { success: true, rootName: rootInfo.name, periods: Object.keys(driveTree) };

  } catch (err) {
    await chrome.storage.local.set({
      driveProgress: { msg: `❌ Error: ${err.message}`, ts: Date.now(), done: true, error: true },
    });
    return { error: err.message };
  }
}

// ──────────────────────────────────────────────
// 4. Handle Folder Info (validasi input user)
// ──────────────────────────────────────────────
async function handleFolderInfo({ url }) {
  const folderId = extractFolderId(url);
  if (!folderId) return { error: 'Format URL tidak dikenali.' };

  let token;
  try {
    token = await getAuthToken(false);
  } catch {
    return { error: 'Belum login. Klik "Hubungkan Google Drive" terlebih dahulu.' };
  }

  try {
    const info = await getFolderInfo(folderId, token);
    return { success: true, ...info };
  } catch (e) {
    return { error: e.message };
  }
}

// ──────────────────────────────────────────────
// 5. Forward pesan ke tab e-Kinerja (dengan auto-inject)
// ──────────────────────────────────────────────
async function forwardToActiveTab(message, sendResponse) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs.length) { sendResponse({ error: 'Tidak ada tab aktif.' }); return; }

  const tab = tabs[0];

  chrome.tabs.sendMessage(tab.id, message, async (response) => {
    const err = chrome.runtime.lastError?.message || '';
    if (!err) { sendResponse(response); return; }

    if (!err.includes('Receiving end') && !err.includes('Could not establish')) {
      sendResponse({ error: err }); return;
    }

    // Auto-inject content.js
    try {
      if (tab.url?.includes('kinerja.bkn.go.id')) {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
        await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content.css'] });
        await new Promise((r) => setTimeout(r, 700));
        chrome.tabs.sendMessage(tab.id, message, (r2) => {
          sendResponse(chrome.runtime.lastError ? { error: chrome.runtime.lastError.message } : r2);
        });
      } else {
        sendResponse({ error: 'Tab aktif bukan halaman e-Kinerja BKN.' });
      }
    } catch (e) {
      sendResponse({ error: `Gagal inject: ${e.message}` });
    }
  });
}
