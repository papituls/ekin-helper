// content.js — Diinjeksi ke kinerja.bkn.go.id
// Tugas: Deteksi tabel RHK e-Kinerja BKN secara presisi & Auto-Fill form Bukti Dukung & Realisasi
'use strict';

function log(...args) {
  console.log('[eKinerja-Helper]', ...args);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Tunggu hingga elemen ditemukan di DOM (dengan timeout).
 */
function waitForElement(selector, timeout = 4000, root = document) {
  return new Promise((resolve, reject) => {
    const found = root.querySelector(selector);
    if (found) { resolve(found); return; }

    const obs = new MutationObserver(() => {
      const el = root.querySelector(selector);
      if (el) { obs.disconnect(); resolve(el); }
    });
    obs.observe(root.body || root, { childList: true, subtree: true });

    setTimeout(() => {
      obs.disconnect();
      reject(new Error(`Timeout: "${selector}" tidak ditemukan dalam ${timeout}ms`));
    }, timeout);
  });
}

/**
 * Isi nilai input/textarea dan picu event React/Vue/Angular/Bootstrap secara sempurna.
 */
function setNativeValue(el, value) {
  if (!el || value === undefined || value === null) return;
  const prototype = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;

  el.focus();
  if (nativeSetter) {
    nativeSetter.call(el, value);
  } else {
    el.value = value;
  }

  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  el.dispatchEvent(new Event('blur', { bubbles: true }));

  // Visual highlight efek hijau saat diisi
  el.classList.add('ekinerja-helper-highlight');
  setTimeout(() => el.classList.remove('ekinerja-helper-highlight'), 3000);
}

// ──────────────────────────────────────────────
// DETEKSI RHK DARI TABEL e-Kinerja BKN
// ──────────────────────────────────────────────

function detectRHK() {
  const results = [];

  // Cari tabel yang berisi kolom "BUKTI DUKUNG" dan "RENCANA HASIL KERJA"
  const tables = [...document.querySelectorAll('table')];
  const targetTable = tables.find((t) => {
    const text = t.textContent.toUpperCase();
    return text.includes('BUKTI DUKUNG') && text.includes('RENCANA HASIL KERJA');
  }) || tables.find((t) => t.textContent.toUpperCase().includes('RENCANA HASIL KERJA'));

  if (!targetTable) {
    log('Tabel RHK tidak ditemukan pada halaman ini.');
    return [];
  }

  log('Tabel RHK ditemukan:', targetTable);

  const rows = [...targetTable.querySelectorAll('tr')];

  // Identifikasi letak indeks kolom dari baris header
  let rhkColIdx = 2; // Default kolom ke-3 (indeks 2) pada e-Kinerja BKN
  let noColIdx = 0;

  for (let r = 0; r < Math.min(rows.length, 4); r++) {
    const headers = [...rows[r].querySelectorAll('th, td')];
    for (let c = 0; c < headers.length; c++) {
      const hText = headers[c].textContent.trim().toUpperCase().replace(/\s+/g, ' ');
      if (hText === 'NO' || hText === 'NO.') {
        noColIdx = c;
      } else if (
        hText.includes('RENCANA HASIL KERJA') &&
        !hText.includes('PIMPINAN') &&
        !hText.includes('INTERVENSI')
      ) {
        rhkColIdx = c;
        log(`Indeks kolom RHK terdeteksi di kolom ke-${c + 1} (indeks ${c})`);
      }
    }
  }

  let runningOrder = 1;

  const isBuktiTable = targetTable.textContent.toUpperCase().includes('BUKTI DUKUNG');
  const minCols = isBuktiTable ? 5 : 3;

  for (const row of rows) {
    const cells = [...row.querySelectorAll('td, th')];
    if (cells.length < minCols) continue; // Skip baris pendek/header colspan (seperti "Utama", "Tambahan")

    // Baris RHK valid di e-Kinerja BKN memiliki ciri:
    // 1. Kolom pertama berisi angka nomor urut (misal: "1", "2", "3")
    // ATAU
    // 2. Baris tersebut memiliki tombol "Tambah" hijau pada kolom Bukti Dukung
    const firstCellText = cells[noColIdx]?.textContent.trim() || cells[0]?.textContent.trim() || '';
    const hasOrderNumber = /^\d+$/.test(firstCellText);
    const hasTambahButton = [...row.querySelectorAll('button, a, span')].some(
      (btn) => btn.textContent.trim().toLowerCase() === 'tambah'
    );

    if (!hasOrderNumber && !hasTambahButton) {
      continue; // Lewati baris judul kategori seperti "Utama", "Tambahan", "RATING", dsb
    }

    // Ambil isi teks RHK dari kolom RHK
    let targetCell = cells[rhkColIdx];
    if (!targetCell && cells.length > 2) {
      targetCell = cells[2];
    }
    if (!targetCell) continue;

    let rhkText = (targetCell.innerText || targetCell.textContent || '').trim().replace(/\s+/g, ' ');

    // Pastikan bukan teks header yang lolos
    if (
      !rhkText ||
      rhkText.length < 5 ||
      rhkText.toUpperCase() === 'RENCANA HASIL KERJA' ||
      rhkText.toUpperCase().includes('PIMPINAN YANG DIINTERVENSI')
    ) {
      continue;
    }

    // Nomor urut
    let orderNum = parseInt(firstCellText, 10);
    if (isNaN(orderNum) || orderNum <= 0) {
      orderNum = runningOrder;
    }
    runningOrder = orderNum + 1;

    // Hindari duplikasi jika ada baris yang berulang
    if (!results.some((x) => x.name.toLowerCase() === rhkText.toLowerCase())) {
      results.push({
        order: orderNum,
        name: rhkText,
      });
      log(`RHK terdeteksi: #${orderNum} - ${rhkText}`);
    }
  }

  results.sort((a, b) => a.order - b.order);
  return results;
}

// ──────────────────────────────────────────────
// AUTO-FILL: BUKTI DUKUNG
// ──────────────────────────────────────────────

async function fillBuktiDukung({ nama, link }) {
  // 1. Cari modal yang sedang aktif/terbuka di halaman
  const modalSelectors = [
    '.modal.show',
    '.modal[style*="display: block"]',
    '[role="dialog"]:not([aria-hidden="true"])',
    '.swal2-modal',
  ];

  let modal = null;
  for (const sel of modalSelectors) {
    modal = document.querySelector(sel);
    if (modal) break;
  }

  if (!modal) {
    try {
      modal = await waitForElement('.modal.show, [role="dialog"]:not([aria-hidden="true"])', 4000);
    } catch {
      return {
        error: 'Modal Bukti Dukung belum terbuka di halaman e-Kinerja. Silakan klik tombol "Tambah" hijau pada baris RHK terlebih dahulu.',
      };
    }
  }

  log('Modal Bukti Dukung aktif:', modal);

  // Cari semua input teks di dalam modal body
  const allInputs = [
    ...modal.querySelectorAll(
      'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), textarea'
    ),
  ];

  let namaInput = null;
  let linkInput = null;

  // Metode A: Cek berdasarkan teks label di sekitarnya
  const labels = [...modal.querySelectorAll('label, .form-label, strong, span, p')];
  for (const label of labels) {
    const lText = label.textContent.trim().toUpperCase();
    const parent = label.closest('.form-group, .mb-3, .form-row, .row, div');
    const input = parent?.querySelector('input:not([type="hidden"]), textarea');

    if (input) {
      if (lText.includes('NAMA BUKTI') || (lText.includes('NAMA') && !lText.includes('PEGAWAI'))) {
        namaInput = input;
      } else if (lText.includes('LINK') || lText.includes('DROPBOX') || lText.includes('BUKTI DUKUNG (LINK') || lText.includes('TAUTAN')) {
        linkInput = input;
      }
    }
  }

  // Metode B: Fallback berdasarkan urutan input modal e-Kinerja:
  // Input 0 = NAMA BUKTI DUKUNG
  // Input 1 = BUKTI DUKUNG (LINK)
  if (!namaInput && allInputs.length > 0) namaInput = allInputs[0];
  if (!linkInput && allInputs.length > 1) linkInput = allInputs[1];

  let filledCount = 0;

  if (namaInput && nama) {
    setNativeValue(namaInput, nama);
    log('Nama Bukti Dukung diisi:', nama);
    filledCount++;
    await sleep(150);
  }

  if (linkInput && link) {
    setNativeValue(linkInput, link);
    log('Link Bukti Dukung diisi:', link);
    filledCount++;
    await sleep(150);
  }

  if (filledCount === 0) {
    return { error: 'Tidak dapat menemukan kolom Nama atau Link di dalam modal Bukti Dukung.' };
  }

  return { success: true, filled: { nama, link } };
}

// ──────────────────────────────────────────────
// AUTO-FILL: REALISASI & SUMBER DATA
// ──────────────────────────────────────────────

async function fillRealisasi({ realisasi, sumberData }) {
  // 1. Cari modal Realisasi yang sedang aktif
  const modalSelectors = [
    '.modal.show',
    '.modal[style*="display: block"]',
    '[role="dialog"]:not([aria-hidden="true"])',
    '.swal2-modal',
  ];

  let modal = null;
  for (const sel of modalSelectors) {
    modal = document.querySelector(sel);
    if (modal) break;
  }

  if (!modal) {
    try {
      modal = await waitForElement('.modal.show, [role="dialog"]:not([aria-hidden="true"])', 4000);
    } catch {
      return {
        error: 'Modal Realisasi belum terbuka di halaman e-Kinerja. Silakan klik tombol "Edit" pada kolom Realisasi terlebih dahulu.',
      };
    }
  }

  log('Modal Realisasi aktif:', modal);

  const allInputs = [
    ...modal.querySelectorAll(
      'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), textarea'
    ),
  ];

  let realisasiInput = null;
  let sumberInput = null;

  // Metode A: Cek berdasarkan teks label
  const labels = [...modal.querySelectorAll('label, .form-label, strong, span, p')];
  for (const label of labels) {
    const lText = label.textContent.trim().toUpperCase();
    const parent = label.closest('.form-group, .mb-3, .form-row, .row, div');
    const input = parent?.querySelector('input:not([type="hidden"]), textarea');

    if (input) {
      if (lText.includes('REALISASI') || lText.includes('CAPAIAN')) {
        realisasiInput = input;
      } else if (lText.includes('SUMBER DATA') || lText.includes('SUMBER')) {
        sumberInput = input;
      }
    }
  }

  // Metode B: Fallback berdasarkan urutan input modal e-Kinerja:
  // Input 0 = REALISASI
  // Input 1 = SUMBER DATA
  if (!realisasiInput && allInputs.length > 0) realisasiInput = allInputs[0];
  if (!sumberInput && allInputs.length > 1) sumberInput = allInputs[1];

  let filledCount = 0;

  if (realisasiInput && realisasi) {
    setNativeValue(realisasiInput, realisasi);
    log('Realisasi diisi:', realisasi);
    filledCount++;
    await sleep(150);
  }

  // Sumber data selalu diisi sama dengan Nama Bukti Dukung
  if (sumberInput && sumberData) {
    setNativeValue(sumberInput, sumberData);
    log('Sumber Data diisi:', sumberData);
    filledCount++;
    await sleep(150);
  }

  if (filledCount === 0) {
    return { error: 'Tidak dapat menemukan kolom Realisasi atau Sumber Data di dalam modal.' };
  }

  return { success: true, filled: { realisasi, sumberData } };
}

// ──────────────────────────────────────────────
// ROBOT RPA: AUTO-CLICK & AUTO-SUBMIT RHK
// ──────────────────────────────────────────────

function findHasilKerjaTable() {
  const tables = [...document.querySelectorAll('table')];
  return (
    tables.find((t) => {
      const text = t.textContent.toUpperCase();
      return text.includes('BUKTI DUKUNG') && text.includes('RENCANA HASIL KERJA');
    }) ||
    tables.find((t) => t.textContent.toUpperCase().includes('RENCANA HASIL KERJA'))
  );
}

function findRencanaAksiTable() {
  const tables = [...document.querySelectorAll('table')];
  // Prioritas 1: Tabel yang memiliki kolom RENCANA AKSI dan RENCANA HASIL KERJA tanpa BUKTI DUKUNG
  let target = tables.find((t) => {
    const text = t.textContent.toUpperCase();
    return text.includes('RENCANA AKSI') && text.includes('RENCANA HASIL KERJA') && !text.includes('BUKTI DUKUNG');
  });
  if (target) return target;

  // Prioritas 2: Tabel yang memiliki kolom RENCANA AKSI
  target = tables.find((t) => {
    const text = t.textContent.toUpperCase();
    return text.includes('RENCANA AKSI') && text.includes('RENCANA HASIL KERJA');
  });
  return target || null;
}

function normalizeText(str) {
  return (str || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function calculateSimilarity(textA, textB) {
  const normA = normalizeText(textA);
  const normB = normalizeText(textB);
  if (!normA || !normB) return 0;
  if (normA === normB) return 1.0;

  const tokensA = new Set(normA.split(' ').filter((w) => w.length > 2));
  const tokensB = new Set(normB.split(' ').filter((w) => w.length > 2));
  if (!tokensA.size || !tokensB.size) return 0;

  let intersection = 0;
  for (const token of tokensA) {
    if (tokensB.has(token)) intersection++;
  }

  const union = new Set([...tokensA, ...tokensB]).size;
  return intersection / union;
}

function getTableColumnIndices(table) {
  let rhkColIdx = -1;
  let noColIdx = -1;
  let buktiColIdx = -1;
  let realisasiColIdx = -1;
  let rencanaAksiColIdx = -1;

  const headerRows = [...table.querySelectorAll('tr')].slice(0, 4);
  for (const hr of headerRows) {
    const headers = [...hr.querySelectorAll('th, td')];
    for (let c = 0; c < headers.length; c++) {
      const hText = headers[c].textContent.trim().toUpperCase().replace(/\s+/g, ' ');
      if (hText === 'NO' || hText === 'NO.' || hText === 'NO URUT' || hText.startsWith('NO.') || hText.startsWith('NO ')) {
        noColIdx = c;
      } else if (
        hText.includes('RENCANA HASIL KERJA') &&
        !hText.includes('PIMPINAN') &&
        !hText.includes('INTERVENSI')
      ) {
        rhkColIdx = c;
      } else if (hText.includes('BUKTI DUKUNG')) {
        buktiColIdx = c;
      } else if (hText.includes('REALISASI')) {
        realisasiColIdx = c;
      } else if (hText.includes('RENCANA AKSI')) {
        rencanaAksiColIdx = c;
      }
    }
  }

  // Fallback: Jika header NO tidak tertulis eksplisit, cek apakah kolom 0 baris data berisi angka (1, 2, 3...)
  if (noColIdx === -1) {
    const dataRows = [...table.querySelectorAll('tr')].filter((r) => r.querySelectorAll('td').length >= 3);
    if (dataRows.length > 0 && /^\d+$/.test(dataRows[0].querySelectorAll('td')[0]?.textContent.trim())) {
      noColIdx = 0;
    }
  }

  if (rhkColIdx === -1) {
    const isRencanaAksi = rencanaAksiColIdx !== -1 || table.textContent.toUpperCase().includes('RENCANA AKSI');
    rhkColIdx = noColIdx !== -1 ? (isRencanaAksi ? noColIdx + 1 : noColIdx + 2) : 1;
  }

  return { rhkColIdx, noColIdx, buktiColIdx, realisasiColIdx, rencanaAksiColIdx };
}

function findRhkRow(order, name, specificTable = null) {
  const table = specificTable || findHasilKerjaTable() || findRencanaAksiTable();
  if (!table) return null;

  const { rhkColIdx, noColIdx } = getTableColumnIndices(table);
  const allRows = [...table.querySelectorAll('tr')];

  // Hanya ambil baris data RHK (memiliki minimal 3 sel dan memiliki tombol aksi)
  const candidateRows = allRows.filter((row) => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 3) return false;
    return [...row.querySelectorAll('button, a, .btn')].some((b) => {
      const t = b.textContent.trim().toLowerCase();
      return t === 'tambah' || t === 'edit' || t === 'isi';
    });
  });

  const normTarget = normalizeText(name);

  // ─────────────────────────────────────────────────────────────
  // STRATEGI 1: Cocokkan NO URUT + VERIFIKASI KESESUAIAN NAMA (Paling Akurat & Presisi)
  // ─────────────────────────────────────────────────────────────
  if (order && noColIdx !== -1) {
    for (const row of candidateRows) {
      const cells = [...row.querySelectorAll('td')];
      if (cells.length <= noColIdx) continue;
      const cellNo = cells[noColIdx].textContent.trim();
      if (cellNo === String(order)) {
        // Verifikasi nama jika ada
        if (normTarget && rhkColIdx !== -1 && cells[rhkColIdx]) {
          const rowRhkText = cells[rhkColIdx].textContent;
          const sim = calculateSimilarity(name, rowRhkText);
          if (sim >= 0.35 || normalizeText(rowRhkText).includes(normTarget.slice(0, 20))) {
            log(`[findRhkRow] Cocok via No. Urut #${order} & Verifikasi Nama (Sim: ${sim.toFixed(2)})`);
            return row;
          }
        } else {
          log(`[findRhkRow] Cocok via No. Urut #${order}`);
          return row;
        }
      }
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STRATEGI 2: Cocokkan PERSIS (EXACT MATCH) pada kolom RHK
  // ─────────────────────────────────────────────────────────────
  if (normTarget && rhkColIdx !== -1) {
    for (const row of candidateRows) {
      const cells = [...row.querySelectorAll('td')];
      if (cells.length <= rhkColIdx) continue;
      const rowRhkNorm = normalizeText(cells[rhkColIdx].textContent);
      if (rowRhkNorm === normTarget) {
        log(`[findRhkRow] Cocok persis 100% pada kolom RHK: "${name}"`);
        return row;
      }
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STRATEGI 3: SKOR KESAMAAN TERTINGGI (Jaccard Token Similarity)
  // ─────────────────────────────────────────────────────────────
  if (normTarget) {
    let bestRow = null;
    let highestScore = 0;

    for (const row of candidateRows) {
      const cells = [...row.querySelectorAll('td')];
      let candidateText = '';
      if (rhkColIdx !== -1 && cells[rhkColIdx]) {
        candidateText = cells[rhkColIdx].textContent;
      } else {
        candidateText = cells.slice(1, Math.max(2, cells.length - 2)).map((c) => c.textContent).join(' ');
      }

      const score = calculateSimilarity(name, candidateText);
      if (score > highestScore) {
        highestScore = score;
        bestRow = row;
      }
    }

    if (bestRow && highestScore >= 0.5) {
      log(`[findRhkRow] Cocok via skor kemiripan tertinggi (${highestScore.toFixed(2)}): "${name}"`);
      return bestRow;
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STRATEGI 4: Nomor Urut saja (jika kolom NO ada)
  // ─────────────────────────────────────────────────────────────
  if (order && noColIdx !== -1) {
    for (const row of candidateRows) {
      const cells = [...row.querySelectorAll('td')];
      if (cells.length <= noColIdx) continue;
      if (cells[noColIdx].textContent.trim() === String(order)) {
        log(`[findRhkRow] Fallback cocok No. Urut #${order}`);
        return row;
      }
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STRATEGI 5: Posisi Indeks Baris (Index urutan ke-N)
  // ─────────────────────────────────────────────────────────────
  if (order && candidateRows[order - 1]) {
    log(`[findRhkRow] Fallback urutan baris ke-${order}`);
    return candidateRows[order - 1];
  }

  return null;
}

function findTambahBuktiButton(row) {
  const table = row.closest('table') || findHasilKerjaTable();
  const { buktiColIdx } = table ? getTableColumnIndices(table) : {};

  // 1. Jika buktiColIdx terdeteksi, cari tombol di kolom Bukti Dukung
  if (buktiColIdx !== undefined && buktiColIdx !== -1) {
    const cells = [...row.querySelectorAll('td')];
    if (cells[buktiColIdx]) {
      const btn = [...cells[buktiColIdx].querySelectorAll('button, a, .btn')].find(
        (b) => b.textContent.trim().toLowerCase() === 'tambah'
      );
      if (btn) return btn;
    }
  }

  // 2. Bukti Dukung selalu kolom ke-2 dari belakang (second to last)
  const cells = [...row.querySelectorAll('td')];
  if (cells.length >= 2) {
    const secondLast = cells[cells.length - 2];
    const btn = [...secondLast.querySelectorAll('button, a, .btn')].find(
      (b) => b.textContent.trim().toLowerCase() === 'tambah'
    );
    if (btn) return btn;
  }

  // 3. Fallback: Cari tombol bertuliskan "tambah" di baris
  const buttons = [...row.querySelectorAll('button, a, span.btn, .btn')];
  return buttons.find((b) => b.textContent.trim().toLowerCase() === 'tambah');
}

function findTambahRencanaAksiButton(row) {
  const table = row.closest('table') || findRencanaAksiTable();
  const { rencanaAksiColIdx } = table ? getTableColumnIndices(table) : {};

  // 1. Jika rencanaAksiColIdx terdeteksi, cari tombol di kolom Rencana Aksi
  if (rencanaAksiColIdx !== undefined && rencanaAksiColIdx !== -1) {
    const cells = [...row.querySelectorAll('td')];
    if (cells[rencanaAksiColIdx]) {
      const btn = [...cells[rencanaAksiColIdx].querySelectorAll('button, a, .btn')].find(
        (b) => b.textContent.trim().toLowerCase() === 'tambah'
      );
      if (btn) return btn;
    }
  }

  // 2. Kolom Rencana Aksi biasanya di kolom paling akhir baris (last child td)
  const cells = [...row.querySelectorAll('td')];
  if (cells.length >= 1) {
    const lastCell = cells[cells.length - 1];
    const btn = [...lastCell.querySelectorAll('button, a, .btn')].find(
      (b) => b.textContent.trim().toLowerCase() === 'tambah'
    );
    if (btn) return btn;
  }

  // 3. Fallback: Cari tombol bertuliskan "tambah" di baris
  const buttons = [...row.querySelectorAll('button, a, span.btn, .btn')];
  return buttons.find((b) => b.textContent.trim().toLowerCase() === 'tambah');
}

function findEditRealisasiButton(row) {
  const table = row.closest('table') || findHasilKerjaTable();
  const { realisasiColIdx } = table ? getTableColumnIndices(table) : {};

  // 1. Jika realisasiColIdx terdeteksi, cari tombol di kolom Realisasi
  if (realisasiColIdx !== undefined && realisasiColIdx !== -1) {
    const cells = [...row.querySelectorAll('td')];
    if (cells[realisasiColIdx]) {
      const btn = cells[realisasiColIdx].querySelector('button, a, .btn');
      if (btn) return btn;
    }
  }

  // 2. Realisasi selalu di kolom terakhir tabel
  const cells = [...row.querySelectorAll('td')];
  if (cells.length >= 1) {
    const lastCell = cells[cells.length - 1];
    const btn = lastCell.querySelector('button, a, .btn');
    if (btn) return btn;
  }

  // 3. Fallback: Cari tombol Edit/Isi di kolom paling akhir
  const buttons = [...row.querySelectorAll('button, a, .btn')];
  return (
    buttons.find((b) => {
      const t = b.textContent.trim().toLowerCase();
      return (t === 'edit' || t === 'isi') && b.closest('td') === row.querySelector('td:last-child');
    }) ||
    buttons.find((b) => {
      const t = b.textContent.trim().toLowerCase();
      return t === 'edit' || t === 'isi';
    })
  );
}

function clickModalOkButton(modal) {
  const buttons = [...modal.querySelectorAll('button, input[type="submit"], a.btn')];
  const okBtn =
    buttons.find((b) => {
      const text = b.textContent.trim().toUpperCase();
      return text === 'OK' || text === 'SIMPAN' || text === 'SUBMIT' || text === 'YA';
    }) ||
    buttons.find((b) => {
      const text = b.textContent.trim().toLowerCase();
      return (
        !text.includes('close') &&
        !text.includes('batal') &&
        (b.classList.contains('btn-primary') || b.classList.contains('btn-success'))
      );
    });

  if (okBtn) {
    okBtn.click();
    return true;
  }
  return false;
}

function waitForModalToClose(modal, timeout = 3000) {
  return new Promise((resolve) => {
    const start = Date.now();
    const interval = setInterval(() => {
      const isVisible =
        modal.classList.contains('show') ||
        modal.style.display === 'block' ||
        modal.getAttribute('aria-hidden') === 'false';
      if (!isVisible || Date.now() - start > timeout) {
        clearInterval(interval);
        resolve();
      }
    }, 100);
  });
}

async function waitForAndDismissAlerts(timeout = 3000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const swalBtn = document.querySelector(
      '.swal2-confirm, .swal-button--confirm, button.swal2-styled, .bootbox-accept, .swal2-actions button'
    );
    if (swalBtn && swalBtn.offsetParent !== null) {
      log('Menemukan konfirmasi/alert SweetAlert, menutup...');
      swalBtn.click();
      await sleep(500);
      break;
    }
    // Cek jika modal dan alert sudah tidak ada
    const swalContainer = document.querySelector('.swal2-container');
    if (!swalContainer && Date.now() - start > 1000) {
      break;
    }
    await sleep(200);
  }

  // Bersihkan sisa backdrop modal bootstrap dan status modal-open jika ada
  await sleep(300);
  document.querySelectorAll('.modal-backdrop').forEach((b) => {
    if (!document.querySelector('.modal.show, .modal[style*="display: block"]')) {
      b.remove();
    }
  });
  if (!document.querySelector('.modal.show, .modal[style*="display: block"]')) {
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('padding-right');
    document.body.style.removeProperty('overflow');
  }
}

/**
 * Robot: Otomatis klik Tambah/Edit -> isi modal -> klik OK (submit) untuk 1 RHK.
 */
async function autoProcessSingleRhk({ order, name, buktiDukung = [], realisasi = '', sumberData = '', autoSubmit = true }) {
  try {
    log(`[Robot] Memproses RHK #${order}: "${name}"`);

    // Pastikan tidak ada alert/modal lama yang masih nyangkut
    await waitForAndDismissAlerts(1500);

    let row = findRhkRow(order, name);
    if (!row) {
      log(`Baris RHK #${order} tidak ditemukan.`);
      return { error: `Baris RHK #${order} ("${(name || '').slice(0, 30)}") tidak ditemukan di tabel e-Kinerja.` };
    }

    row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    row.classList.add('ekinerja-row-processing');

    // 1. Proses Pengisian Bukti Dukung
    if (buktiDukung && buktiDukung.length > 0) {
      for (let bi = 0; bi < buktiDukung.length; bi++) {
        const bd = buktiDukung[bi];
        if (!bd.nama && !bd.link) continue;

        // Ambil baris DOM segar (fresh) karena DOM mungkin diperbarui setelah save sebelumnya
        row = findRhkRow(order, name) || row;
        const tambahBtn = findTambahBuktiButton(row);
        if (!tambahBtn) {
          log(`Tombol Tambah tidak ditemukan pada RHK #${order}`);
          break;
        }

        // Buka modal
        tambahBtn.click();
        const modal = await waitForElement(
          '.modal.show, .modal[style*="display: block"], [role="dialog"]:not([aria-hidden="true"])',
          5000
        );
        await sleep(400);

        // Isi form
        const resFill = await fillBuktiDukung(bd);
        if (resFill.error) {
          log('Gagal isi Bukti Dukung:', resFill.error);
        }

        if (autoSubmit) {
          await sleep(400);
          clickModalOkButton(modal);
          log(`Modal Bukti Dukung #${bi + 1} disubmit: "${bd.nama}"`);
          await waitForModalToClose(modal, 3000);
          await waitForAndDismissAlerts(3000);
          await sleep(800); // jeda stabilisasi AJAX e-Kinerja
        }
      }
    }

    // 2. Proses Pengisian Realisasi & Sumber Data
    if (realisasi || sumberData) {
      // Ambil baris DOM segar (fresh) setelah pengisian bukti dukung
      row = findRhkRow(order, name) || row;
      const editBtn = findEditRealisasiButton(row);
      if (editBtn) {
        editBtn.click();
        const modal = await waitForElement(
          '.modal.show, .modal[style*="display: block"], [role="dialog"]:not([aria-hidden="true"])',
          5000
        );
        await sleep(400);

        // Isi Realisasi & Sumber Data
        const resFill = await fillRealisasi({ realisasi, sumberData });
        if (resFill.error) {
          log('Gagal isi Realisasi:', resFill.error);
        }

        if (autoSubmit) {
          await sleep(400);
          clickModalOkButton(modal);
          log(`Modal Realisasi disubmit untuk RHK #${order}`);
          await waitForModalToClose(modal, 3000);
          await waitForAndDismissAlerts(3000);
          await sleep(800); // jeda stabilisasi AJAX e-Kinerja
        }
      } else {
        log(`Tombol Edit Realisasi tidak ditemukan pada RHK #${order}`);
      }
    }

    return { success: true, order, name };
  } catch (err) {
    log(`Error robot pada RHK #${order}:`, err);
    return { error: err.message || String(err) };
  } finally {
    document.querySelectorAll('.ekinerja-row-processing').forEach((r) => r.classList.remove('ekinerja-row-processing'));
  }
}

// ──────────────────────────────────────────────
// AUTO-FILL: RENCANA AKSI & TARGET
// ──────────────────────────────────────────────

async function fillRencanaAksiModal({ aksi, target }) {
  const modalSelectors = [
    '.modal.show',
    '.modal[style*="display: block"]',
    '[role="dialog"]:not([aria-hidden="true"])',
    '.swal2-modal',
  ];

  let modal = null;
  for (const sel of modalSelectors) {
    modal = document.querySelector(sel);
    if (modal) break;
  }

  if (!modal) {
    try {
      modal = await waitForElement('.modal.show, [role="dialog"]:not([aria-hidden="true"])', 4000);
    } catch {
      return {
        error: 'Modal Tambah Rencana Aksi belum terbuka di halaman e-Kinerja.',
      };
    }
  }

  log('Modal Rencana Aksi aktif:', modal);

  const allInputs = [
    ...modal.querySelectorAll(
      'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), textarea'
    ),
  ];

  let aksiInput = null;
  let targetInput = null;

  // Metode A: Cek berdasarkan teks label di sekitarnya
  const labels = [...modal.querySelectorAll('label, .form-label, strong, span, p')];
  for (const label of labels) {
    const lText = label.textContent.trim().toUpperCase();
    const parent = label.closest('.form-group, .mb-3, .form-row, .row, div');
    const input = parent?.querySelector('input:not([type="hidden"]), textarea');

    if (input) {
      if (lText.includes('RENCANA AKSI') || (lText.includes('AKSI') && !lText.includes('INDIKATOR'))) {
        aksiInput = input;
      } else if (lText.includes('TARGET')) {
        targetInput = input;
      }
    }
  }

  // Metode B: Fallback urutan input modal e-Kinerja (Input 0 = Rencana Aksi, Input 1 = Target)
  if (!aksiInput && allInputs.length > 0) aksiInput = allInputs[0];
  if (!targetInput && allInputs.length > 1) targetInput = allInputs[1];

  let filledCount = 0;

  if (aksiInput && aksi) {
    setNativeValue(aksiInput, aksi);
    log('Rencana Aksi diisi:', aksi);
    filledCount++;
    await sleep(150);
  }

  // Kolom target opsional: Hanya isi jika ada nilainya
  if (targetInput && target) {
    setNativeValue(targetInput, target);
    log('Target Rencana Aksi diisi:', target);
    filledCount++;
    await sleep(150);
  }

  if (filledCount === 0) {
    return { error: 'Tidak dapat menemukan kolom Rencana Aksi di dalam modal.' };
  }

  return { success: true, filled: { aksi, target } };
}

/**
 * Robot: Otomatis klik Tambah Rencana Aksi -> isi modal -> submit untuk 1 RHK.
 */
async function autoProcessSingleRhkRencanaAksi({ order, name, rencanaAksiList = [], autoSubmit = true }) {
  try {
    log(`[Robot Rencana Aksi] Memproses RHK #${order}: "${name}"`);

    // Pastikan tidak ada alert/modal lama yang masih nyangkut
    await waitForAndDismissAlerts(1500);

    const raTable = findRencanaAksiTable();
    if (!raTable) {
      return { error: 'Tabel Rencana Aksi tidak ditemukan pada halaman ini. Pastikan Anda berada di halaman Rencana Aksi SKP e-Kinerja.' };
    }

    let row = findRhkRow(order, name, raTable);
    if (!row) {
      log(`Baris RHK #${order} tidak ditemukan di tabel Rencana Aksi.`);
      return { error: `Baris RHK #${order} ("${(name || '').slice(0, 30)}") tidak ditemukan di tabel Rencana Aksi.` };
    }

    row.scrollIntoView({ behavior: 'smooth', block: 'center' });
    row.classList.add('ekinerja-row-processing');

    if (!rencanaAksiList || rencanaAksiList.length === 0) {
      return { success: true, message: 'Tidak ada Rencana Aksi untuk RHK ini.' };
    }

    for (let i = 0; i < rencanaAksiList.length; i++) {
      const item = rencanaAksiList[i];
      const aksiText = typeof item === 'string' ? item : item.aksi;
      const targetText = typeof item === 'object' ? item.target : '';

      if (!aksiText) continue;

      // Ambil baris DOM segar (fresh) karena DOM mungkin di-render ulang setelah submit modal sebelumnya
      row = findRhkRow(order, name, raTable) || row;
      const tambahBtn = findTambahRencanaAksiButton(row);
      if (!tambahBtn) {
        log(`Tombol Tambah Rencana Aksi tidak ditemukan pada RHK #${order}`);
        break;
      }

      // Klik tombol Tambah
      tambahBtn.click();
      const modal = await waitForElement(
        '.modal.show, .modal[style*="display: block"], [role="dialog"]:not([aria-hidden="true"])',
        5000
      );
      await sleep(400);

      // Isi modal
      const resFill = await fillRencanaAksiModal({ aksi: aksiText, target: targetText });
      if (resFill.error) {
        log('Gagal isi Rencana Aksi:', resFill.error);
      }

      if (autoSubmit) {
        await sleep(400);
        clickModalOkButton(modal);
        log(`Modal Rencana Aksi #${i + 1} disubmit: "${aksiText}"`);
        await waitForModalToClose(modal, 3000);
        await waitForAndDismissAlerts(3000);
        await sleep(800); // jeda stabilisasi AJAX e-Kinerja
      }
    }

    return { success: true, order, name };
  } catch (err) {
    log(`Error robot Rencana Aksi pada RHK #${order}:`, err);
    return { error: err.message || String(err) };
  } finally {
    document.querySelectorAll('.ekinerja-row-processing').forEach((r) => r.classList.remove('ekinerja-row-processing'));
  }
}

// ──────────────────────────────────────────────
// OBSERVER & MESSAGE LISTENER
// ──────────────────────────────────────────────

function initModalObserver() {
  const observer = new MutationObserver(() => {
    const modal = document.querySelector('.modal.show, [role="dialog"]:not([aria-hidden="true"])');
    if (modal) {
      chrome.runtime.sendMessage({
        type: 'MODAL_STATUS',
        payload: { open: true, timestamp: Date.now() },
      }).catch(() => {});
    }
  });

  observer.observe(document.body, { childList: true, subtree: true, attributes: true });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;

  switch (type) {
    case 'DETECT_RHK': {
      const rhkList = detectRHK();
      log('Hasil deteksi RHK:', rhkList);
      sendResponse({ rhkList });
      break;
    }

    case 'FILL_BUKTI_DUKUNG': {
      fillBuktiDukung(payload).then(sendResponse);
      return true;
    }

    case 'FILL_REALISASI': {
      fillRealisasi(payload).then(sendResponse);
      return true;
    }

    case 'AUTO_FILL_RHK_SINGLE': {
      autoProcessSingleRhk(payload)
        .then((res) => sendResponse(res || { success: true }))
        .catch((err) => sendResponse({ error: err.message || String(err) }));
      return true;
    }

    case 'FILL_RENCANA_AKSI': {
      fillRencanaAksiModal(payload).then(sendResponse);
      return true;
    }

    case 'AUTO_FILL_RENCANA_AKSI_SINGLE': {
      autoProcessSingleRhkRencanaAksi(payload)
        .then((res) => sendResponse(res || { success: true }))
        .catch((err) => sendResponse({ error: err.message || String(err) }));
      return true;
    }

    case 'PING': {
      sendResponse({ alive: true });
      break;
    }

    default:
      break;
  }
});

log('Content script e-Kinerja siap di:', window.location.href);
initModalObserver();

