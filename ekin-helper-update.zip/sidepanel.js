// sidepanel.js v2.0 — Main UI Logic
// Menggunakan Google Drive API (bukan DOM scraping)
'use strict';

// ══════════════════════════════════════════════════════════════════
// 0. CONSTANTS & HELPERS
// ══════════════════════════════════════════════════════════════════

const PERIODS = ['TW1', 'TW2', 'TW3', 'TW4', 'Tahunan'];
const PERIOD_LABELS = { TW1: 'Triwulan 1', TW2: 'Triwulan 2', TW3: 'Triwulan 3', TW4: 'Triwulan 4', Tahunan: 'Tahunan' };
const ROMAN_MAP = { TW1: 'I', TW2: 'II', TW3: 'III', TW4: 'IV', Tahunan: '' };
const NUM_MAP = { TW1: '1', TW2: '2', TW3: '3', TW4: '4', Tahunan: '' };

function formatRencanaAksiText(text, period, formatType = 'romawi') {
  if (!text || !period) return text;
  const val = formatType === 'angka' ? (NUM_MAP[period] || '') : (ROMAN_MAP[period] || '');
  if (!val) return text;

  let res = text;
  // 1. Explicit placeholders
  res = res.replace(/\{tw\}|\{triwulan\}/gi, val);
  res = res.replace(/\{romawi\}|\{tw_romawi\}/gi, ROMAN_MAP[period] || '');
  res = res.replace(/\{angka\}|\{tw_angka\}/gi, NUM_MAP[period] || '');

  // 2. Ends with TW or Triwulan
  if (/\b(TW|tw|Triwulan|triwulan|TRIWULAN)\s*$/.test(res)) {
    res = res.replace(/\b(TW|tw|Triwulan|triwulan|TRIWULAN)\s*$/, `$1 ${val}`);
  } else {
    // 3. Word TW or Triwulan inside text not followed by digits or roman numeral
    res = res.replace(/\b(TW|tw|Triwulan|triwulan|TRIWULAN)\b(?!\s+(?:[0-9]+|[IVXLCDM]+|ke-|Ke-))/g, `$1 ${val}`);
  }

  return res;
}

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function msgBg(type, payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, payload }, (r) => {
      if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
      else resolve(r || {});
    });
  });
}

function log(...args) {
  console.log('[eKinerja-SidePanel]', ...args);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getStorage(...keys) {
  return new Promise((r) => chrome.storage.local.get(keys, r));
}

function setStorage(obj) {
  return new Promise((r) => chrome.storage.local.set(obj, r));
}

function showToast(text, type = '', duration = 3000) {
  const c = $('#toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = text;
  c.appendChild(t);
  setTimeout(() => {
    t.style.animation = 'toastOut 0.3s ease forwards';
    setTimeout(() => t.remove(), 300);
  }, duration);
}

function showStatus(elId, text, type = 'info') {
  const el = document.getElementById(elId);
  if (!el) return;
  el.className = `status-box ${type}`;
  el.textContent = text;
  el.classList.remove('hidden');
}

function hideStatus(elId) {
  document.getElementById(elId)?.classList.add('hidden');
}

function confirmDialog(title, message) {
  return new Promise((resolve) => {
    const modal = $('#modal-confirm');
    $('#confirm-title').textContent = title;
    $('#confirm-message').textContent = message;
    modal.classList.remove('hidden');
    const ok = $('#confirm-ok');
    const cancel = $('#confirm-cancel');
    const cleanup = (v) => {
      modal.classList.add('hidden');
      ok.removeEventListener('click', onOk);
      cancel.removeEventListener('click', onCancel);
      resolve(v);
    };
    const onOk = () => cleanup(true);
    const onCancel = () => cleanup(false);
    ok.addEventListener('click', onOk);
    cancel.addEventListener('click', onCancel);
  });
}

function escapeHtml(s) {
  if (!s) return '';
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => showToast('✅ Disalin!', 'success', 1500));
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function mimeIcon(mimeType) {
  if (!mimeType) return '📄';
  if (mimeType === 'application/vnd.google-apps.folder') return '📁';
  if (mimeType.includes('pdf')) return '📕';
  if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return '📗';
  if (mimeType.includes('document') || mimeType.includes('word')) return '📘';
  if (mimeType.includes('presentation')) return '📙';
  if (mimeType.includes('image')) return '🖼️';
  return '📄';
}

// ══════════════════════════════════════════════════════════════════
// 1. TAB NAVIGATION
// ══════════════════════════════════════════════════════════════════

function initTabs() {
  $$('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      $$('.tab-btn').forEach((b) => b.classList.remove('active'));
      $$('.tab-content').forEach((c) => c.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab)?.classList.add('active');
      const tab = btn.dataset.tab;
      if (tab === 'tab-drive') refreshDriveTab();
      if (tab === 'tab-rhk') renderRHKList();
      if (tab === 'tab-template') renderTemplateList();
      if (tab === 'tab-autofill') renderAutofillList();
    });
  });
}

// ══════════════════════════════════════════════════════════════════
// 2. AUTH / GOOGLE CONNECT
// ══════════════════════════════════════════════════════════════════

async function checkAuth() {
  const badge = $('#auth-badge');
  const label = badge.querySelector('.auth-label');
  const panel = $('#auth-panel');

  const result = await msgBg('AUTH_CHECK');

  if (result.loggedIn) {
    badge.className = 'auth-badge auth-ok';
    label.textContent = 'Terhubung';
    panel.classList.add('hidden');
    $('#btn-scan-drive').disabled = false;
  } else {
    badge.className = 'auth-badge auth-err';
    label.textContent = 'Belum terhubung';
    panel.classList.remove('hidden');
    $('#btn-scan-drive').disabled = true;
  }

  // Tampilkan ID ekstensi & Redirect URI untuk kemudahan verifikasi
  const idEl = $('#auth-ext-id');
  const uriEl = $('#auth-redirect-uri');
  if (idEl) idEl.textContent = chrome.runtime.id;
  if (uriEl) uriEl.textContent = chrome.identity.getRedirectURL();

  return result.loggedIn;
}

function initAuth() {
  $('#btn-connect-drive').addEventListener('click', async () => {
    $('#btn-connect-drive').disabled = true;
    $('#btn-connect-drive').textContent = 'Menghubungkan...';
    const res = await msgBg('AUTH_LOGIN');
    if (res.success) {
      showToast('✅ Google Drive terhubung!', 'success');
      await checkAuth();
    } else {
      showToast(`❌ Gagal: ${res.error}`, 'error', 5000);
      $('#btn-connect-drive').disabled = false;
      $('#btn-connect-drive').textContent = 'Hubungkan';
    }
  });
}

// ══════════════════════════════════════════════════════════════════
// 3. DRIVE TAB — Root Folder Input & Scan
// ══════════════════════════════════════════════════════════════════

async function refreshDriveTab() {
  await checkAuth();
  await renderRootFolderDisplay();
  await renderDriveTree();
}

async function renderRootFolderDisplay() {
  const { currentRootId, currentRootName } = await getStorage('currentRootId', 'currentRootName');
  const display = $('#root-folder-display');

  if (currentRootId && currentRootName) {
    const url = `https://drive.google.com/drive/folders/${currentRootId}`;
    display.innerHTML = `
      <div class="root-folder-info">
        <span>📁</span>
        <div class="root-folder-text">
          <strong>${escapeHtml(currentRootName)}</strong>
          <a href="${url}" target="_blank" class="root-folder-link">${url.slice(0, 50)}...</a>
        </div>
      </div>`;
  } else {
    display.innerHTML = `<span class="text-muted">Belum ada folder dipilih. Klik "Ganti" untuk memilih.</span>`;
    // Auto-buka input area jika belum ada root
    $('#root-folder-input-area').classList.remove('hidden');
  }
}

function initDriveTab() {

  // Tombol Ganti folder root
  $('#btn-change-root').addEventListener('click', () => {
    const area = $('#root-folder-input-area');
    area.classList.toggle('hidden');
    if (!area.classList.contains('hidden')) {
      $('#root-folder-url').focus();
    }
  });

  $('#btn-cancel-root').addEventListener('click', () => {
    $('#root-folder-input-area').classList.add('hidden');
    hideStatus('folder-validate-status');
  });

  // Validasi folder sebelum disimpan
  $('#btn-validate-folder').addEventListener('click', async () => {
    const url = $('#root-folder-url').value.trim();
    if (!url) { showStatus('folder-validate-status', '❌ Masukkan URL folder terlebih dahulu.', 'error'); return; }

    showStatus('folder-validate-status', '⏳ Memvalidasi folder...', 'info');
    $('#btn-validate-folder').disabled = true;

    const res = await msgBg('DRIVE_FOLDER_INFO', { url });
    $('#btn-validate-folder').disabled = false;

    if (res.error) {
      showStatus('folder-validate-status', `❌ ${res.error}`, 'error');
      return;
    }

    if (!res.isFolder) {
      showStatus('folder-validate-status', '❌ Link tersebut bukan folder. Pastikan link mengarah ke folder, bukan file.', 'error');
      return;
    }

    showStatus('folder-validate-status', `✅ Folder ditemukan: "${res.name}"`, 'success');
    await setStorage({ currentRootId: res.id, currentRootName: res.name });
    setTimeout(async () => {
      $('#root-folder-input-area').classList.add('hidden');
      hideStatus('folder-validate-status');
      await renderRootFolderDisplay();
      $('#btn-scan-drive').disabled = false;
    }, 1000);
  });

  // Enter key di input URL → validate
  $('#root-folder-url').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#btn-validate-folder').click();
  });

  // Tombol Scan
  $('#btn-scan-drive').addEventListener('click', startDriveScan);
}

async function startDriveScan() {
  const { currentRootId } = await getStorage('currentRootId');
  if (!currentRootId) {
    showStatus('scan-status', '❌ Pilih folder induk terlebih dahulu.', 'error');
    return;
  }

  // Ambil periode yang dicentang
  const selectedPeriods = $$('#period-checkboxes input:checked').map((cb) => cb.value);
  if (!selectedPeriods.length) {
    showStatus('scan-status', '❌ Pilih minimal satu periode.', 'error');
    return;
  }

  // Tampilkan progress
  hideStatus('scan-status');
  const progressBox = $('#scan-progress-box');
  const progressText = $('#scan-progress-text');
  progressBox.classList.remove('hidden');
  progressText.textContent = 'Memulai scan...';
  $('#btn-scan-drive').disabled = true;

  // Polling progress dari storage
  const progressInterval = setInterval(async () => {
    const { driveProgress } = await getStorage('driveProgress');
    if (driveProgress?.msg) {
      progressText.textContent = driveProgress.msg;
    }
  }, 500);

  const res = await msgBg('DRIVE_SCAN', {
    rootUrl: currentRootId,
    periods: selectedPeriods,
  });

  clearInterval(progressInterval);
  progressBox.classList.add('hidden');
  $('#btn-scan-drive').disabled = false;

  if (res.error) {
    showStatus('scan-status', `❌ ${res.error}`, 'error');
  } else {
    showStatus('scan-status',
      `✅ Scan selesai! ${res.periods?.length || 0} periode berhasil dibaca: ${(res.periods || []).map((p) => PERIOD_LABELS[p] || p).join(', ')}`,
      'success');
    await renderDriveTree();
  }
}

// ══════════════════════════════════════════════════════════════════
// 4. DRIVE TREE RENDER
// ══════════════════════════════════════════════════════════════════

async function renderDriveTree() {
  const container = $('#drive-tree-container');
  const badgesEl = $('#period-badges');
  const { driveTree } = await getStorage('driveTree');

  if (!driveTree || Object.keys(driveTree).length === 0) {
    container.innerHTML = `<div class="empty-state"><span>📭</span><p>Belum ada data Drive.<br/>Klik "Scan Struktur Drive" untuk memulai.</p></div>`;
    badgesEl.innerHTML = '';
    return;
  }

  // Period badges
  badgesEl.innerHTML = Object.keys(driveTree).map((p) => {
    const d = driveTree[p];
    const count = d.rhkList?.length || 0;
    return `<span class="period-badge has-data">${PERIOD_LABELS[p] || p} <span class="badge-count">${count} RHK</span></span>`;
  }).join('');

  // Build tree HTML
  let html = '';
  for (const [periodKey, periodData] of Object.entries(driveTree)) {
    const rhkList = periodData.rhkList || [];
    const ts = periodData.scannedAt ? new Date(periodData.scannedAt).toLocaleString('id-ID') : '';

    html += `<div class="tree-period">
      <div class="tree-period-header" data-period="${periodKey}">
        <span class="chevron">▶</span>
        <span>📅 ${escapeHtml(periodData.periodLabel || PERIOD_LABELS[periodKey])}</span>
        <span class="tree-meta">${rhkList.length} RHK · ${ts}</span>
      </div>
      <div class="tree-period-body" id="period-body-${periodKey}">`;

    for (const rhk of rhkList) {
      const totalItems = rhk.items?.length || 0;
      html += `<div class="tree-rhk">
        <div class="tree-rhk-header" data-rhk="${escapeHtml(rhk.rhkId)}">
          <span class="chevron">▶</span>
          <span class="rhk-num-badge">${rhk.rhkOrder ? `RHK ${rhk.rhkOrder}` : '📂'}</span>
          <span class="tree-rhk-name">${escapeHtml(rhk.rhkName)}</span>
          <span class="tree-meta">${totalItems} item</span>
        </div>
        <div class="tree-rhk-body" id="rhk-body-${escapeHtml(rhk.rhkId)}">
          <!-- Link folder RHK itu sendiri -->
          <div class="tree-item tree-item-folder tree-item-parent">
            <span class="item-icon">📁</span>
            <span class="item-name">📌 ${escapeHtml(rhk.rhkName)} (Folder)</span>
            <div class="item-actions">
              <a href="${escapeHtml(rhk.folderUrl)}" target="_blank" class="btn-item-link" title="Buka di Drive">🔗</a>
              <button class="btn-item-copy"
                data-name="${escapeHtml(rhk.rhkName)}"
                data-url="${escapeHtml(rhk.folderUrl)}"
                title="Salin nama & link">📋</button>
              <button class="btn-item-use"
                data-name="${escapeHtml(rhk.rhkName)}"
                data-url="${escapeHtml(rhk.folderUrl)}"
                data-period="${periodKey}"
                data-rhk-id="${escapeHtml(rhk.rhkId)}"
                title="Gunakan sebagai Bukti Dukung">➕</button>
            </div>
          </div>`;

      // Items dalam RHK (file langsung & subfolder)
      for (const item of (rhk.items || [])) {
        if (item.type === 'folder') {
          html += `
          <div class="tree-item tree-item-subfolder">
            <span class="item-icon">📁</span>
            <span class="item-name">${escapeHtml(item.name)}</span>
            <div class="item-actions">
              <a href="${escapeHtml(item.url)}" target="_blank" class="btn-item-link">🔗</a>
              <button class="btn-item-copy" data-name="${escapeHtml(item.name)}" data-url="${escapeHtml(item.url)}">📋</button>
              <button class="btn-item-use" data-name="${escapeHtml(item.name)}" data-url="${escapeHtml(item.url)}" data-period="${periodKey}" data-rhk-id="${escapeHtml(rhk.rhkId)}">➕</button>
            </div>
          </div>`;
          // File dalam subfolder
          for (const f of (item.files || [])) {
            html += `
          <div class="tree-item tree-item-file tree-item-indent2">
            <span class="item-icon">${mimeIcon(f.mimeType)}</span>
            <span class="item-name">${escapeHtml(f.name)}</span>
            <div class="item-actions">
              <a href="${escapeHtml(f.url)}" target="_blank" class="btn-item-link">🔗</a>
              <button class="btn-item-copy" data-name="${escapeHtml(f.name)}" data-url="${escapeHtml(f.url)}">📋</button>
              <button class="btn-item-use" data-name="${escapeHtml(f.name)}" data-url="${escapeHtml(f.url)}" data-period="${periodKey}" data-rhk-id="${escapeHtml(rhk.rhkId)}">➕</button>
            </div>
          </div>`;
          }
        } else {
          html += `
          <div class="tree-item tree-item-file">
            <span class="item-icon">${mimeIcon(item.mimeType)}</span>
            <span class="item-name">${escapeHtml(item.name)}</span>
            <div class="item-actions">
              <a href="${escapeHtml(item.url)}" target="_blank" class="btn-item-link">🔗</a>
              <button class="btn-item-copy" data-name="${escapeHtml(item.name)}" data-url="${escapeHtml(item.url)}">📋</button>
              <button class="btn-item-use" data-name="${escapeHtml(item.name)}" data-url="${escapeHtml(item.url)}" data-period="${periodKey}" data-rhk-id="${escapeHtml(rhk.rhkId)}">➕</button>
            </div>
          </div>`;
        }
      }

      html += `</div></div>`; // close rhk-body, tree-rhk
    }

    html += `</div></div>`; // close period-body, tree-period
  }

  container.innerHTML = html;
  attachTreeEvents(container);
}

function attachTreeEvents(container) {
  // Toggle periode
  container.querySelectorAll('.tree-period-header').forEach((hdr) => {
    hdr.addEventListener('click', () => {
      hdr.classList.toggle('open');
      document.getElementById(`period-body-${hdr.dataset.period}`)?.classList.toggle('open');
    });
  });

  // Toggle RHK
  container.querySelectorAll('.tree-rhk-header').forEach((hdr) => {
    hdr.addEventListener('click', () => {
      hdr.classList.toggle('open');
      document.getElementById(`rhk-body-${hdr.dataset.rhk}`)?.classList.toggle('open');
    });
  });

  // Copy nama & link
  container.querySelectorAll('.btn-item-copy').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyToClipboard(`${btn.dataset.name}\n${btn.dataset.url}`);
    });
  });

  // Gunakan sebagai bukti dukung → tambah ke RHK
  container.querySelectorAll('.btn-item-use').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const { name, url, period, rhkId } = btn.dataset;
      await addBuktiDukungFromDrive(period, rhkId, name, url);
    });
  });
}

/**
 * Tombol ➕ di tree Drive:
 * Buka modal pilihan RHK sehingga user bisa menentukan bukti dukung ini
 * dimasukkan ke RHK yang mana!
 */
async function addBuktiDukungFromDrive(period, rhkId, name, url) {
  const list = await getRHKData(period);

  if (!list.length) {
    showToast('❌ Belum ada daftar RHK. Klik "🔎 Deteksi" di tab RHK terlebih dahulu.', 'error');
    return;
  }

  // Tampilkan modal picker agar user bisa memilih RHK tujuan
  const modal = $('#modal-picker');
  $('#picker-title').textContent = 'Pilih RHK Tujuan';
  $('#picker-desc').textContent = `Tambahkan bukti dukung "${name}" ke RHK:`;

  const container = $('#picker-list');
  container.innerHTML = list.map((rhk, idx) => `
    <div class="picker-item" data-id="${rhk.id}">
      <span class="picker-item-icon">📋</span>
      <div class="picker-item-info">
        <div class="picker-item-title">${rhk.order ? `RHK ${rhk.order}` : `RHK ${idx + 1}`}: ${escapeHtml(rhk.name)}</div>
        <div class="picker-item-sub">${(rhk.buktiDukung || []).length} Bukti Dukung terdaftar</div>
      </div>
    </div>
  `).join('');

  modal.classList.remove('hidden');

  // Event klik pada item picker
  container.querySelectorAll('.picker-item').forEach((item) => {
    item.addEventListener('click', async () => {
      const targetId = item.dataset.id;
      const targetRhk = list.find((r) => r.id === targetId);
      if (!targetRhk) return;

      targetRhk.buktiDukung = targetRhk.buktiDukung || [];

      // Cek apakah link sudah ada di RHK ini
      if (targetRhk.buktiDukung.some((b) => b.link === url)) {
        showToast('⚠️ Item ini sudah ada di RHK tersebut.', 'warning');
        modal.classList.add('hidden');
        return;
      }

      targetRhk.buktiDukung.push({ nama: name, link: url });

      // Sumber data otomatis mengikuti bukti pertama jika belum ada
      if (!targetRhk.sumberData) {
        targetRhk.sumberData = targetRhk.buktiDukung[0].nama;
      }

      await saveRHKData(period, list);
      modal.classList.add('hidden');
      renderRHKList();
      showToast(`✅ Ditambahkan ke RHK ${targetRhk.order}: "${name}"`, 'success');
    });
  });
}

// ══════════════════════════════════════════════════════════════════
// 5. RHK TAB
// ══════════════════════════════════════════════════════════════════

let editingRHKId = null;
let buktiFormCount = 0;

async function getRHKData(period) {
  const { rhkData } = await getStorage('rhkData');
  return (rhkData || {})[period] || [];
}

async function saveRHKData(period, list) {
  const { rhkData } = await getStorage('rhkData');
  const all = rhkData || {};
  all[period] = list;
  await setStorage({ rhkData: all });
}

async function renderRHKList() {
  const period = $('#rhk-period-select').value;
  const container = $('#rhk-list-container');
  const list = await getRHKData(period);

  if (!list.length) {
    container.innerHTML = `<div class="empty-state"><span>📭</span><p>Belum ada RHK untuk ${PERIOD_LABELS[period]}.</p></div>`;
    return;
  }

  container.innerHTML = list.map((rhk, idx) => `
    <div class="rhk-card" data-id="${rhk.id}">
      <div class="rhk-card-header">
        <div class="rhk-number">${rhk.order || idx + 1}</div>
        <div class="rhk-name">${escapeHtml(rhk.name)}</div>
        <div class="rhk-actions">
          <button class="rhk-action-btn edit" data-id="${rhk.id}">✏️</button>
          <button class="rhk-action-btn delete" data-id="${rhk.id}">🗑️</button>
          <button class="rhk-action-btn" data-id="${rhk.id}" data-action="up">⬆️</button>
          <button class="rhk-action-btn" data-id="${rhk.id}" data-action="down">⬇️</button>
        </div>
      </div>
      <div class="rhk-card-body">
        ${(rhk.buktiDukung || []).map((bd, bi) => `
          <div class="bukti-dukung-item">
            <span class="bukti-num">${bi + 1}.</span>
            <span class="bukti-name">${escapeHtml(bd.nama)}</span>
            ${bd.link ? `<a class="bukti-link" href="${escapeHtml(bd.link)}" target="_blank">🔗</a>` : ''}
            <button class="btn-copy-cell" data-copy="${escapeHtml(bd.nama + '\n' + (bd.link || ''))}">📋</button>
          </div>`).join('')}
        ${(rhk.rencanaAksi && rhk.rencanaAksi.length > 0) ? `
          <div class="rhk-aksi-section">
            <div class="rhk-section-title">📋 Rencana Aksi (${rhk.rencanaAksi.length})</div>
            ${rhk.rencanaAksi.map((ra, rai) => `
              <div class="rhk-aksi-item">
                <span class="aksi-num">${rai + 1}.</span>
                <span class="aksi-text">${escapeHtml(ra.aksi)}${ra.target ? ` <span class="badge-target">Target: ${escapeHtml(ra.target)}</span>` : ''}</span>
              </div>
            `).join('')}
          </div>` : ''}
        <div class="rhk-realisasi-row">
          <span class="realisasi-label">Realisasi:</span>
          <span class="realisasi-value">${escapeHtml(rhk.realisasi || '—')}</span>
          <span class="realisasi-label">Sumber:</span>
          <span class="realisasi-value">${escapeHtml(rhk.sumberData || '—')}</span>
        </div>
      </div>
    </div>`).join('');

  container.querySelectorAll('.edit').forEach((b) => b.addEventListener('click', () => openRHKModal(b.dataset.id, period)));
  container.querySelectorAll('.delete').forEach((b) => b.addEventListener('click', async () => {
    if (!await confirmDialog('Hapus RHK?', 'Data akan dihapus permanen.')) return;
    const updated = (await getRHKData(period)).filter((r) => r.id !== b.dataset.id);
    await saveRHKData(period, updated);
    renderRHKList();
    showToast('🗑️ RHK dihapus.', 'error');
  }));
  container.querySelectorAll('[data-action="up"]').forEach((b) => b.addEventListener('click', () => moveRHK(b.dataset.id, 'up', period)));
  container.querySelectorAll('[data-action="down"]').forEach((b) => b.addEventListener('click', () => moveRHK(b.dataset.id, 'down', period)));
  container.querySelectorAll('.btn-copy-cell').forEach((b) => b.addEventListener('click', () => copyToClipboard(b.dataset.copy)));
}

async function moveRHK(id, dir, period) {
  const list = await getRHKData(period);
  const idx = list.findIndex((r) => r.id === id);
  const ni = dir === 'up' ? idx - 1 : idx + 1;
  if (ni < 0 || ni >= list.length) return;
  [list[idx], list[ni]] = [list[ni], list[idx]];
  await saveRHKData(period, list);
  renderRHKList();
}

function addBuktiForm(nama = '', link = '') {
  buktiFormCount++;
  const c = $('#bukti-dukung-list');
  const div = document.createElement('div');
  div.className = 'bukti-form-item';
  div.innerHTML = `
    <button class="btn-remove-bukti" title="Hapus">✕</button>
    <div class="bukti-form-row">
      <label>Nama</label>
      <input type="text" class="bukti-nama" placeholder="Nama dokumen/folder" value="${escapeHtml(nama)}" />
    </div>
    <div class="bukti-form-row">
      <label>Link</label>
      <div style="display: flex; gap: 4px; width: 100%;">
        <input type="text" class="bukti-link-input" placeholder="https://drive.google.com/..." value="${escapeHtml(link)}" style="flex: 1;" />
        <button type="button" class="btn-pick-drive-file btn-sm btn-secondary" title="Pilih dari hasil scan Drive" style="white-space: nowrap; font-size: 10px; padding: 3px 8px;">📁 Drive</button>
      </div>
    </div>`;

  div.querySelector('.btn-remove-bukti').addEventListener('click', () => { div.remove(); updateSumberData(); });
  div.querySelector('.bukti-nama').addEventListener('input', updateSumberData);

  // Tombol ambil dari Drive di dalam form modal
  div.querySelector('.btn-pick-drive-file').addEventListener('click', async () => {
    const period = $('#rhk-period-select').value;
    const { driveTree } = await getStorage('driveTree');
    const periodData = driveTree?.[period];

    if (!periodData?.rhkList?.length) {
      showToast(`❌ Belum ada hasil scan Drive untuk ${PERIOD_LABELS[period] || period}. Scan terlebih dahulu di tab Drive.`, 'error');
      return;
    }

    // Kumpulkan semua file dan folder dari Drive periode ini
    const allDriveItems = [];
    for (const rhk of periodData.rhkList) {
      // Masukkan folder RHK itu sendiri
      allDriveItems.push({ name: `[Folder] ${rhk.rhkName}`, url: rhk.folderUrl, isFolder: true });
      for (const item of (rhk.items || [])) {
        if (item.type === 'folder') {
          allDriveItems.push({ name: `[Folder] ${item.name}`, url: item.url, isFolder: true });
          for (const f of (item.files || [])) {
            allDriveItems.push({ name: f.name, url: f.url, isFolder: false });
          }
        } else {
          allDriveItems.push({ name: item.name, url: item.url, isFolder: false });
        }
      }
    }

    const modal = $('#modal-picker');
    $('#picker-title').textContent = 'Pilih Berkas dari Drive';
    $('#picker-desc').textContent = 'Klik pada berkas atau folder untuk memasukkan Nama dan Link ke form:';

    const container = $('#picker-list');
    container.innerHTML = allDriveItems.map((item, idx) => `
      <div class="picker-item" data-idx="${idx}">
        <span class="picker-item-icon">${item.isFolder ? '📁' : '📄'}</span>
        <div class="picker-item-info">
          <div class="picker-item-title">${escapeHtml(item.name)}</div>
          <div class="picker-item-sub">${escapeHtml(item.url)}</div>
        </div>
      </div>
    `).join('');

    modal.classList.remove('hidden');

    container.querySelectorAll('.picker-item').forEach((pItem) => {
      pItem.addEventListener('click', () => {
        const selected = allDriveItems[parseInt(pItem.dataset.idx, 10)];
        if (!selected) return;

        // Isi Link
        div.querySelector('.bukti-link-input').value = selected.url;

        // Jika Nama belum diisi atau masih default, isi otomatis dari nama file
        const cleanName = selected.name.replace(/^\[Folder\]\s*/, '');
        const namaInput = div.querySelector('.bukti-nama');
        if (!namaInput.value.trim()) {
          namaInput.value = cleanName;
        }

        updateSumberData();
        modal.classList.add('hidden');
        showToast(`✅ Terpilih: "${cleanName}"`, 'success');
      });
    });
  });

  c.appendChild(div);
}

let rencanaFormCount = 0;

function addRencanaAksiForm(aksi = '', target = '') {
  rencanaFormCount++;
  const c = $('#rencana-aksi-list');
  if (!c) return;
  const div = document.createElement('div');
  div.className = 'rencana-form-item';
  div.innerHTML = `
    <button type="button" class="btn-remove-rencana" title="Hapus">✕</button>
    <div class="rencana-form-row">
      <label>Rencana Aksi</label>
      <textarea class="rencana-aksi-input" rows="2" placeholder="Contoh: Menyusun Laporan Kinerja TW">${escapeHtml(aksi)}</textarea>
    </div>
    <div class="rencana-form-row">
      <label>Target <span class="hint">(opsional, boleh dikosongkan)</span></label>
      <input type="text" class="rencana-target-input" placeholder="Contoh: 1 Laporan (boleh kosong)" value="${escapeHtml(target)}" />
    </div>
  `;

  div.querySelector('.btn-remove-rencana').addEventListener('click', () => { div.remove(); });
  c.appendChild(div);
}

function updateSumberData() {
  $('#rhk-sumber-input').value = $('#bukti-dukung-list .bukti-nama')?.value || '';
}

function openRHKModal(id = null, period = null) {
  period = period || $('#rhk-period-select').value;
  editingRHKId = id;
  buktiFormCount = 0;
  rencanaFormCount = 0;
  $('#modal-rhk-title').textContent = id ? 'Edit RHK' : 'Tambah RHK Baru';
  $('#rhk-name-input').value = '';
  $('#rhk-order-input').value = '';
  $('#rhk-realisasi-input').value = '';
  $('#rhk-sumber-input').value = '';
  $('#bukti-dukung-list').innerHTML = '';
  $('#rencana-aksi-list').innerHTML = '';

  if (id) {
    getRHKData(period).then((list) => {
      const rhk = list.find((r) => r.id === id);
      if (!rhk) return;
      $('#rhk-name-input').value = rhk.name || '';
      $('#rhk-order-input').value = rhk.order || '';
      $('#rhk-realisasi-input').value = rhk.realisasi || '';
      $('#rhk-sumber-input').value = rhk.sumberData || '';
      (rhk.buktiDukung || []).forEach((bd) => addBuktiForm(bd.nama, bd.link));
      if (!rhk.buktiDukung?.length) addBuktiForm();
      (rhk.rencanaAksi || []).forEach((ra) => addRencanaAksiForm(ra.aksi, ra.target));
      if (!rhk.rencanaAksi?.length) addRencanaAksiForm();
    });
  } else {
    addBuktiForm();
    addRencanaAksiForm();
  }
  $('#modal-rhk').classList.remove('hidden');
}

function initRHKTab() {
  $('#rhk-period-select').addEventListener('change', renderRHKList);
  $('#btn-add-rhk').addEventListener('click', () => openRHKModal());
  $('#btn-add-bukti').addEventListener('click', () => addBuktiForm());
  $('#btn-add-rencana-aksi')?.addEventListener('click', () => addRencanaAksiForm());

  $('#btn-import-from-drive').addEventListener('click', async () => {
    const period = $('#rhk-period-select').value;
    const { driveTree } = await getStorage('driveTree');
    const periodData = driveTree?.[period];
    if (!periodData?.rhkList?.length) {
      showToast(`❌ Tidak ada data Drive untuk ${PERIOD_LABELS[period]}. Scan terlebih dahulu.`, 'error'); return;
    }
    const existing = await getRHKData(period);
    let added = 0;
    for (const rhk of periodData.rhkList) {
      if (existing.some((r) => r.driveRhkId === rhk.rhkId)) continue;
      // Ambil item pertama sebagai default bukti dukung
      const firstItem = rhk.items?.[0];
      existing.push({
        id: generateId(),
        driveRhkId: rhk.rhkId,
        name: rhk.rhkName,
        order: rhk.rhkOrder || existing.length + 1,
        buktiDukung: firstItem ? [{ nama: firstItem.name, link: firstItem.url }] : [],
        realisasi: '',
        sumberData: firstItem?.name || '',
      });
      added++;
    }
    await saveRHKData(period, existing);
    renderRHKList();
    showToast(`✅ ${added} RHK diimport dari Drive.`, 'success');
  });

  $('#btn-detect-rhk').addEventListener('click', async () => {
    const period = $('#rhk-period-select').value;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('kinerja.bkn.go.id')) {
      showToast('❌ Buka halaman e-Kinerja terlebih dahulu.', 'error');
      return;
    }

    chrome.tabs.sendMessage(tab.id, { type: 'DETECT_RHK' }, async (r) => {
      if (!r?.rhkList?.length) {
        showToast('⚠️ Tidak ada RHK yang terdeteksi di tabel halaman ini.', 'warning');
        return;
      }

      const existing = await getRHKData(period);

      // Bersihkan RHK sampah dari deteksi lama (Utama, Tambahan, Rating, BerAKHLAK)
      const cleanExisting = existing.filter((x) => {
        const u = x.name.trim().toUpperCase();
        return (
          u !== 'UTAMA' &&
          u !== 'TAMBAHAN' &&
          !u.includes('RATING HASIL') &&
          !u.includes('MEMAHAMI DAN') &&
          !u.includes('PERILAKU KERJA')
        );
      });

      let added = 0;
      r.rhkList.forEach((item) => {
        const name = typeof item === 'string' ? item.trim() : item.name.trim();
        const order = typeof item === 'object' && item.order ? item.order : cleanExisting.length + 1;

        const found = cleanExisting.find((x) => x.name.toLowerCase() === name.toLowerCase());
        if (!found) {
          cleanExisting.push({
            id: generateId(),
            name,
            order,
            buktiDukung: [],
            realisasi: '',
            sumberData: '',
          });
          added++;
        } else {
          // Update order nomor urut jika berubah
          found.order = order;
        }
      });

      cleanExisting.sort((a, b) => (a.order || 999) - (b.order || 999));

      await saveRHKData(period, cleanExisting);
      renderRHKList();
      showToast(`✅ ${r.rhkList.length} RHK berhasil dideteksi & diperbarui!`, 'success');
    });
  });

  $('#btn-clear-rhk').addEventListener('click', async () => {
    const period = $('#rhk-period-select').value;
    if (!await confirmDialog('Hapus Semua RHK?', `Semua RHK untuk ${PERIOD_LABELS[period]} akan dihapus.`)) return;
    await saveRHKData(period, []);
    renderRHKList();
    showToast('🗑️ Semua RHK dihapus.', 'error');
  });

  $('#btn-save-rhk').addEventListener('click', async () => {
    const period = $('#rhk-period-select').value;
    const name = $('#rhk-name-input').value.trim();
    if (!name) { showToast('❌ Nama RHK tidak boleh kosong.', 'error'); return; }
    const buktiDukung = $$('#bukti-dukung-list .bukti-form-item').map((d) => ({
      nama: d.querySelector('.bukti-nama')?.value.trim() || '',
      link: d.querySelector('.bukti-link-input')?.value.trim() || '',
    })).filter((b) => b.nama);
    const rencanaAksi = $$('#rencana-aksi-list .rencana-form-item').map((d) => ({
      aksi: d.querySelector('.rencana-aksi-input')?.value.trim() || '',
      target: d.querySelector('.rencana-target-input')?.value.trim() || '',
    })).filter((r) => r.aksi);
    const rhkObj = {
      id: editingRHKId || generateId(),
      name,
      order: parseInt($('#rhk-order-input').value) || 0,
      buktiDukung,
      rencanaAksi,
      realisasi: $('#rhk-realisasi-input').value.trim(),
      sumberData: $('#rhk-sumber-input').value.trim() || buktiDukung[0]?.nama || '',
      updatedAt: new Date().toISOString(),
    };
    const list = await getRHKData(period);
    const idx = editingRHKId ? list.findIndex((r) => r.id === editingRHKId) : -1;
    if (idx >= 0) list[idx] = rhkObj; else list.push(rhkObj);
    list.forEach((r, i) => { if (!r.order) r.order = i + 1; });
    await saveRHKData(period, list);
    $('#modal-rhk').classList.add('hidden');
    renderRHKList();
    showToast('✅ RHK disimpan.', 'success');
    editingRHKId = null;
  });
}

// ══════════════════════════════════════════════════════════════════
// 6. TEMPLATE TAB
// ══════════════════════════════════════════════════════════════════

async function getTemplates() {
  const { templates } = await getStorage('templates');
  return templates || {};
}

async function renderTemplateList() {
  const tpls = await getTemplates();
  const container = $('#template-list');
  const copyBox = $('#copy-template-box');
  const copySelect = $('#template-copy-name');
  if (!Object.keys(tpls).length) {
    container.innerHTML = `<div class="empty-state"><span>📭</span><p>Belum ada template.</p></div>`;
    copyBox.classList.add('hidden'); return;
  }
  copyBox.classList.remove('hidden');
  copySelect.innerHTML = Object.keys(tpls).map((k) => `<option value="${escapeHtml(k)}">${escapeHtml(k)}</option>`).join('');
  container.innerHTML = Object.entries(tpls).map(([name, t]) =>
    `<div class="template-card">
      <div class="template-info">
        <div class="template-name">📋 ${escapeHtml(name)}</div>
        <div class="template-meta">${PERIOD_LABELS[t.period] || t.period} · ${(t.rhkList || []).length} RHK · ${t.savedAt ? new Date(t.savedAt).toLocaleDateString('id-ID') : ''}</div>
      </div>
      <div class="template-actions">
        <button class="template-btn delete-tpl" data-name="${escapeHtml(name)}">🗑️</button>
      </div>
    </div>`).join('');
  container.querySelectorAll('.delete-tpl').forEach((b) => b.addEventListener('click', async () => {
    if (!await confirmDialog('Hapus Template?', `"${b.dataset.name}" akan dihapus.`)) return;
    const tpls = await getTemplates();
    delete tpls[b.dataset.name];
    await setStorage({ templates: tpls });
    renderTemplateList();
    showToast('🗑️ Template dihapus.', 'error');
  }));
}

function initTemplateTab() {
  $('#btn-save-template').addEventListener('click', async () => {
    const period = $('#template-source-period').value;
    const list = await getRHKData(period);
    if (!list.length) { showToast('❌ Tidak ada RHK untuk periode ini.', 'error'); return; }
    const { settings } = await getStorage('settings');
    const defaultName = `${PERIOD_LABELS[period]} ${settings?.year || new Date().getFullYear()}`;
    const name = window.prompt('Nama template:', defaultName);
    if (!name) return;
    const tpls = await getTemplates();
    tpls[name] = { period, rhkList: list, savedAt: new Date().toISOString() };
    await setStorage({ templates: tpls });
    renderTemplateList();
    showToast(`✅ Template "${name}" tersimpan.`, 'success');
  });

  $('#btn-export-json').addEventListener('click', async () => {
    const data = await getStorage('rhkData', 'driveTree', 'templates', 'settings', 'currentRootId', 'currentRootName');
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `ekinerja-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('✅ Export berhasil.', 'success');
  });

  $('#btn-import-json').addEventListener('click', () => $('#import-file-input').click());
  $('#import-file-input').addEventListener('change', async (e) => {
    const file = e.target.files[0]; if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      await setStorage(data);
      showToast('✅ Data diimport!', 'success');
      refreshDriveTab(); renderRHKList(); renderTemplateList();
    } catch (err) { showToast(`❌ File tidak valid: ${err.message}`, 'error'); }
    e.target.value = '';
  });

  $('#btn-apply-template').addEventListener('click', async () => {
    const name = $('#template-copy-name').value;
    const targetPeriod = $('#template-target-period').value;
    const keepLinks = $('#copy-keep-links').checked;
    const tpls = await getTemplates();
    const tmpl = tpls[name];
    if (!tmpl) { showToast('❌ Template tidak ditemukan.', 'error'); return; }
    if (!await confirmDialog('Terapkan Template?', `Copy "${name}" ke ${PERIOD_LABELS[targetPeriod]}?`)) return;
    const newList = (tmpl.rhkList || []).map((r) => ({
      ...r, id: generateId(),
      buktiDukung: (r.buktiDukung || []).map((b) => ({ nama: b.nama, link: keepLinks ? b.link : '' })),
      rencanaAksi: (r.rencanaAksi || []).map((a) => ({ aksi: a.aksi, target: a.target || '' })),
    }));
    await saveRHKData(targetPeriod, newList);
    showToast(`✅ Diterapkan ke ${PERIOD_LABELS[targetPeriod]}.`, 'success');
    renderRHKList();
  });
}

// ══════════════════════════════════════════════════════════════════
// 7. AUTO-FILL TAB
// ══════════════════════════════════════════════════════════════════

let currentAutofillMode = 'bukti';
let isBatchRunning = false;
let shouldCancelBatch = false;
let isBatchAksiRunning = false;
let shouldCancelBatchAksi = false;

async function renderAutofillList() {
  const period = $('#autofill-period-select').value;
  const container = $('#autofill-rhk-list');
  const list = await getRHKData(period);
  if (!list.length) {
    container.innerHTML = `<div class="empty-state"><span>📭</span><p>Tidak ada RHK untuk ${PERIOD_LABELS[period]}.</p></div>`; return;
  }

  if (currentAutofillMode === 'aksi') {
    const formatType = $('#aksi-tw-format-select')?.value || 'romawi';
    container.innerHTML = list.map((rhk, idx) => {
      const aksiList = rhk.rencanaAksi || [];
      return `
        <div class="autofill-rhk-card">
          <div class="autofill-rhk-header">
            <div class="rhk-number">${rhk.order || idx + 1}</div>
            <div class="rhk-name">${escapeHtml(rhk.name)}</div>
          </div>
          <div class="autofill-rhk-body">
            ${aksiList.length > 0 ? aksiList.map((ra, rai) => {
              const formattedAksi = formatRencanaAksiText(ra.aksi, period, formatType);
              return `
                <div class="rhk-aksi-item" style="padding: 4px 0; border-bottom: 1px solid var(--surface-3);">
                  <span class="aksi-num">${rai + 1}.</span>
                  <span class="aksi-text" style="font-size: 11px;">
                    ${escapeHtml(formattedAksi)}
                    ${ra.target ? ` <span class="badge-target">Target: ${escapeHtml(ra.target)}</span>` : ''}
                  </span>
                </div>
              `;
            }).join('') : '<div style="font-size: 11px; color: var(--text-disabled); font-style: italic; padding: 4px 0;">Belum ada Rencana Aksi untuk RHK ini.</div>'}
            <div class="autofill-btn-row mt-4">
              <button class="btn-autofill-single-aksi" data-rhk-id="${rhk.id}" ${aksiList.length === 0 ? 'disabled style="opacity: 0.5;"' : ''} title="Otomatis klik Tambah, isi Rencana Aksi & Target untuk RHK ini">
                📋 Auto-Fill Rencana Aksi RHK Ini
              </button>
              <button class="btn-autofill-copy-aksi" data-rhk-id="${rhk.id}">📄 Salin</button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    container.querySelectorAll('.btn-autofill-single-aksi').forEach((btn) => {
      btn.addEventListener('click', () => autoFillSingleRencanaAksiHandler(period, btn.dataset.rhkId));
    });

    container.querySelectorAll('.btn-autofill-copy-aksi').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const l = await getRHKData(period);
        const rhk = l.find((r) => r.id === btn.dataset.rhkId);
        if (!rhk) return;
        const fmt = $('#aksi-tw-format-select')?.value || 'romawi';
        const lines = [
          `RHK #${rhk.order || ''}: ${rhk.name}`,
          ...(rhk.rencanaAksi || []).map((a, i) => `${i + 1}. ${formatRencanaAksiText(a.aksi, period, fmt)}${a.target ? ` (Target: ${a.target})` : ''}`)
        ];
        copyToClipboard(lines.join('\n'));
      });
    });
    return;
  }

  // Mode Bukti Dukung & Realisasi
  container.innerHTML = list.map((rhk, idx) => `
    <div class="autofill-rhk-card">
      <div class="autofill-rhk-header">
        <div class="rhk-number">${rhk.order || idx + 1}</div>
        <div class="rhk-name">${escapeHtml(rhk.name)}</div>
      </div>
      <div class="autofill-rhk-body">
        ${(rhk.buktiDukung || []).map((bd, bi) => `
          <div class="bukti-dukung-item">
            <span class="bukti-num">${bi + 1}.</span>
            <span class="bukti-name">${escapeHtml(bd.nama)}</span>
            <button class="btn-autofill-bukti" data-rhk-id="${rhk.id}" data-bukti-idx="${bi}">📋 Bukti ${bi + 1}</button>
          </div>`).join('')}
        <div class="autofill-btn-row mt-4">
          <button class="btn-autofill-single-rhk" data-rhk-id="${rhk.id}" title="Otomatis klik, isi Bukti Dukung & Realisasi untuk RHK ini">⚡ Auto-Fill RHK Ini</button>
          <button class="btn-autofill-realisasi" data-rhk-id="${rhk.id}">📊 Realisasi</button>
          <button class="btn-autofill-copy" data-rhk-id="${rhk.id}">📄 Salin</button>
        </div>
      </div>
    </div>`).join('');

  container.querySelectorAll('.btn-autofill-bukti').forEach((btn) => {
    btn.addEventListener('click', () => fillBuktiDukung(period, btn.dataset.rhkId, parseInt(btn.dataset.buktiIdx)));
  });
  container.querySelectorAll('.btn-autofill-realisasi').forEach((btn) => {
    btn.addEventListener('click', () => fillRealisasi(period, btn.dataset.rhkId));
  });
  container.querySelectorAll('.btn-autofill-single-rhk').forEach((btn) => {
    btn.addEventListener('click', () => autoFillSingleRhkHandler(period, btn.dataset.rhkId));
  });
  container.querySelectorAll('.btn-autofill-copy').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const l = await getRHKData(period);
      const rhk = l.find((r) => r.id === btn.dataset.rhkId);
      if (!rhk) return;
      const lines = [`RHK: ${rhk.name}`, ...(rhk.buktiDukung || []).map((b, i) => `Bukti ${i + 1}: ${b.nama}\n${b.link}`), `Realisasi: ${rhk.realisasi}`, `Sumber: ${rhk.sumberData}`];
      copyToClipboard(lines.join('\n'));
    });
  });
}

function initBatchAutoFill() {
  $$('.autofill-mode-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      $$('.autofill-mode-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      currentAutofillMode = btn.dataset.mode;

      if (currentAutofillMode === 'aksi') {
        $('#batch-card-bukti')?.classList.add('hidden');
        $('#batch-card-aksi')?.classList.remove('hidden');
        $('#info-box-bukti')?.classList.add('hidden');
        $('#info-box-aksi')?.classList.remove('hidden');
      } else {
        $('#batch-card-bukti')?.classList.remove('hidden');
        $('#batch-card-aksi')?.classList.add('hidden');
        $('#info-box-bukti')?.classList.remove('hidden');
        $('#info-box-aksi')?.classList.add('hidden');
      }
      renderAutofillList();
    });
  });

  $('#aksi-tw-format-select')?.addEventListener('change', () => {
    if (currentAutofillMode === 'aksi') renderAutofillList();
  });

  $('#btn-batch-fill-all')?.addEventListener('click', async () => {
    const period = $('#autofill-period-select').value;
    await runBatchAutoFill(period);
  });

  $('#btn-batch-cancel')?.addEventListener('click', () => {
    shouldCancelBatch = true;
    showToast('🛑 Menghentikan proses batch...', 'warning');
  });

  $('#btn-batch-fill-aksi-all')?.addEventListener('click', async () => {
    const period = $('#autofill-period-select').value;
    await runBatchAutoFillRencanaAksi(period);
  });

  $('#btn-batch-aksi-cancel')?.addEventListener('click', () => {
    shouldCancelBatchAksi = true;
    showToast('🛑 Menghentikan proses batch Rencana Aksi...', 'warning');
  });
}

async function autoFillSingleRhkHandler(period, rhkId) {
  const list = await getRHKData(period);
  const rhk = list.find((r) => r.id === rhkId);
  if (!rhk) return;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('kinerja.bkn.go.id')) {
    showToast('❌ Buka halaman e-Kinerja BKN terlebih dahulu.', 'error');
    return;
  }

  showToast(`⏳ Menjalankan Auto-Fill untuk RHK #${rhk.order}...`, 'info', 2000);
  const sumberData = rhk.sumberData || rhk.buktiDukung?.[0]?.nama || '';

  chrome.tabs.sendMessage(
    tab.id,
    {
      type: 'AUTO_FILL_RHK_SINGLE',
      payload: {
        order: rhk.order,
        name: rhk.name,
        buktiDukung: rhk.buktiDukung || [],
        realisasi: rhk.realisasi,
        sumberData,
        autoSubmit: true,
      },
    },
    (res) => {
      if (chrome.runtime.lastError || res?.error) {
        showToast(`❌ Gagal: ${res?.error || chrome.runtime.lastError?.message}`, 'error', 4000);
      } else {
        showToast(`✅ RHK #${rhk.order} selesai diisi & disimpan!`, 'success');
      }
    }
  );
}

async function runBatchAutoFill(period) {
  if (isBatchRunning) return;

  const btnStart = $('#btn-batch-fill-all');
  const btnCancel = $('#btn-batch-cancel');
  const progressBox = $('#batch-progress-box');
  const progressBar = $('#batch-progress-bar');
  const progressText = $('#batch-progress-text');

  try {
    const list = await getRHKData(period);
    if (!list.length) {
      showToast(`❌ Tidak ada data RHK untuk ${PERIOD_LABELS[period]}.`, 'error');
      return;
    }

    const readyRhk = list.filter((r) => (r.buktiDukung && r.buktiDukung.length > 0) || r.realisasi);
    if (!readyRhk.length) {
      showToast('⚠️ Belum ada Bukti Dukung atau Realisasi pada RHK periode ini.', 'warning');
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('kinerja.bkn.go.id')) {
      showToast('❌ Buka halaman e-Kinerja BKN terlebih dahulu.', 'error');
      return;
    }

    isBatchRunning = true;
    shouldCancelBatch = false;

    btnStart?.classList.add('hidden');
    btnCancel?.classList.remove('hidden');
    progressBox?.classList.remove('hidden');

    let successCount = 0;
    let failCount = 0;

    for (let i = 0; i < readyRhk.length; i++) {
      if (shouldCancelBatch) {
        showToast('🛑 Proses batch dihentikan oleh pengguna.', 'warning');
        break;
      }

      const rhk = readyRhk[i];
      const pct = Math.round((i / readyRhk.length) * 100);
      if (progressBar) progressBar.style.width = `${pct}%`;
      if (progressText) {
        progressText.textContent = `[${i + 1}/${readyRhk.length}] RHK #${rhk.order || i + 1}: ${(rhk.name || '').slice(0, 30)}...`;
      }

      const sumberData = rhk.sumberData || rhk.buktiDukung?.[0]?.nama || '';

      // Safety timeout 45 detik per RHK agar tidak pernah hang / macet tanpa henti
      const res = await new Promise((resolve) => {
        let isSettled = false;
        const timeoutTimer = setTimeout(() => {
          if (!isSettled) {
            isSettled = true;
            resolve({ error: 'Batas waktu 45 detik terlampaui (timeout).' });
          }
        }, 45000);

        chrome.tabs.sendMessage(
          tab.id,
          {
            type: 'AUTO_FILL_RHK_SINGLE',
            payload: {
              order: rhk.order || i + 1,
              name: rhk.name,
              buktiDukung: rhk.buktiDukung || [],
              realisasi: rhk.realisasi,
              sumberData,
              autoSubmit: true,
            },
          },
          (r) => {
            if (isSettled) return;
            isSettled = true;
            clearTimeout(timeoutTimer);
            if (chrome.runtime.lastError || r?.error) {
              resolve({ error: chrome.runtime.lastError?.message || r?.error });
            } else {
              resolve({ success: true });
            }
          }
        );
      });

      if (res.success) {
        successCount++;
      } else {
        failCount++;
        log(`Gagal pada RHK #${rhk.order || i + 1}:`, res.error);
        showToast(`⚠️ RHK #${rhk.order || i + 1}: ${res.error}`, 'warning', 3500);
      }

      const completedPct = Math.round(((i + 1) / readyRhk.length) * 100);
      if (progressBar) progressBar.style.width = `${completedPct}%`;

      await sleep(1000); // jeda aman 1 detik antar baris RHK
    }

    if (progressBar) progressBar.style.width = '100%';
    if (progressText) {
      progressText.textContent = `Selesai! ${successCount} berhasil${failCount > 0 ? `, ${failCount} gagal/dilewati` : ''}.`;
    }

    showToast(`🎉 Batch Auto-Fill selesai! (${successCount} RHK berhasil diisi)`, 'success', 5000);
  } catch (err) {
    log('Batch auto-fill error:', err);
    showToast(`❌ Error batch: ${err.message}`, 'error', 5000);
    if (progressText) progressText.textContent = `Error: ${err.message}`;
  } finally {
    isBatchRunning = false;
    btnStart?.classList.remove('hidden');
    btnCancel?.classList.add('hidden');
  }
}

async function autoFillSingleRencanaAksiHandler(period, rhkId) {
  const list = await getRHKData(period);
  const rhk = list.find((r) => r.id === rhkId);
  if (!rhk) return;

  const aksiList = rhk.rencanaAksi || [];
  if (!aksiList.length) {
    showToast('⚠️ RHK ini belum memiliki Rencana Aksi.', 'warning');
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('kinerja.bkn.go.id')) {
    showToast('❌ Buka halaman e-Kinerja BKN terlebih dahulu.', 'error');
    return;
  }

  const formatType = $('#aksi-tw-format-select')?.value || 'romawi';
  const formattedAksiList = aksiList.map((ra) => ({
    aksi: formatRencanaAksiText(ra.aksi, period, formatType),
    target: ra.target || '',
  }));

  showToast(`⏳ Menjalankan Auto-Fill Rencana Aksi untuk RHK #${rhk.order}...`, 'info', 2000);

  chrome.tabs.sendMessage(
    tab.id,
    {
      type: 'AUTO_FILL_RENCANA_AKSI_SINGLE',
      payload: {
        order: rhk.order,
        name: rhk.name,
        rencanaAksiList: formattedAksiList,
        autoSubmit: true,
      },
    },
    (res) => {
      if (chrome.runtime.lastError || res?.error) {
        showToast(`❌ Gagal: ${res?.error || chrome.runtime.lastError?.message}`, 'error', 4000);
      } else {
        showToast(`✅ Rencana Aksi RHK #${rhk.order} selesai diisi & disimpan!`, 'success');
      }
    }
  );
}

async function runBatchAutoFillRencanaAksi(period) {
  if (isBatchAksiRunning) return;

  const btnStart = $('#btn-batch-fill-aksi-all');
  const btnCancel = $('#btn-batch-aksi-cancel');
  const progressBox = $('#batch-aksi-progress-box');
  const progressBar = $('#batch-aksi-progress-bar');
  const progressText = $('#batch-aksi-progress-text');

  try {
    const list = await getRHKData(period);
    if (!list.length) {
      showToast(`❌ Tidak ada data RHK untuk ${PERIOD_LABELS[period]}.`, 'error');
      return;
    }

    const readyRhk = list.filter((r) => r.rencanaAksi && r.rencanaAksi.length > 0);
    if (!readyRhk.length) {
      showToast('⚠️ Belum ada Rencana Aksi pada RHK periode ini. Atur di tab RHK.', 'warning');
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('kinerja.bkn.go.id')) {
      showToast('❌ Buka halaman e-Kinerja BKN terlebih dahulu.', 'error');
      return;
    }

    isBatchAksiRunning = true;
    shouldCancelBatchAksi = false;

    btnStart?.classList.add('hidden');
    btnCancel?.classList.remove('hidden');
    progressBox?.classList.remove('hidden');

    let successCount = 0;
    let failCount = 0;
    const formatType = $('#aksi-tw-format-select')?.value || 'romawi';

    for (let i = 0; i < readyRhk.length; i++) {
      if (shouldCancelBatchAksi) {
        showToast('🛑 Proses batch Rencana Aksi dihentikan oleh pengguna.', 'warning');
        break;
      }

      const rhk = readyRhk[i];
      const pct = Math.round((i / readyRhk.length) * 100);
      if (progressBar) progressBar.style.width = `${pct}%`;
      if (progressText) {
        progressText.textContent = `[${i + 1}/${readyRhk.length}] RHK #${rhk.order || i + 1}: ${(rhk.name || '').slice(0, 30)}...`;
      }

      const formattedAksiList = (rhk.rencanaAksi || []).map((ra) => ({
        aksi: formatRencanaAksiText(ra.aksi, period, formatType),
        target: ra.target || '',
      }));

      // Safety timeout 45 detik per RHK
      const res = await new Promise((resolve) => {
        let isSettled = false;
        const timeoutTimer = setTimeout(() => {
          if (!isSettled) {
            isSettled = true;
            resolve({ error: 'Batas waktu 45 detik terlampaui (timeout).' });
          }
        }, 45000);

        chrome.tabs.sendMessage(
          tab.id,
          {
            type: 'AUTO_FILL_RENCANA_AKSI_SINGLE',
            payload: {
              order: rhk.order || i + 1,
              name: rhk.name,
              rencanaAksiList: formattedAksiList,
              autoSubmit: true,
            },
          },
          (r) => {
            if (isSettled) return;
            isSettled = true;
            clearTimeout(timeoutTimer);
            if (chrome.runtime.lastError || r?.error) {
              resolve({ error: chrome.runtime.lastError?.message || r?.error });
            } else {
              resolve({ success: true });
            }
          }
        );
      });

      if (res.success) {
        successCount++;
      } else {
        failCount++;
        log(`Gagal Rencana Aksi pada RHK #${rhk.order || i + 1}:`, res.error);
        showToast(`⚠️ RHK #${rhk.order || i + 1}: ${res.error}`, 'warning', 3500);
      }

      const completedPct = Math.round(((i + 1) / readyRhk.length) * 100);
      if (progressBar) progressBar.style.width = `${completedPct}%`;

      await sleep(1000); // jeda aman 1 detik antar baris RHK
    }

    if (progressBar) progressBar.style.width = '100%';
    if (progressText) {
      progressText.textContent = `Selesai! ${successCount} berhasil${failCount > 0 ? `, ${failCount} gagal/dilewati` : ''}.`;
    }

    showToast(`🎉 Batch Rencana Aksi selesai! (${successCount} RHK berhasil diisi)`, 'success', 5000);
  } catch (err) {
    log('Batch Rencana Aksi error:', err);
    showToast(`❌ Error batch Rencana Aksi: ${err.message}`, 'error', 5000);
    if (progressText) progressText.textContent = `Error: ${err.message}`;
  } finally {
    isBatchAksiRunning = false;
    btnStart?.classList.remove('hidden');
    btnCancel?.classList.add('hidden');
  }
}

async function fillBuktiDukung(period, rhkId, buktiIdx) {
  const list = await getRHKData(period);
  const rhk = list.find((r) => r.id === rhkId);
  const bd = rhk?.buktiDukung?.[buktiIdx];
  if (!bd) { showToast('❌ Data tidak ditemukan.', 'error'); return; }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('kinerja.bkn.go.id')) { showToast('❌ Buka halaman e-Kinerja terlebih dahulu.', 'error'); return; }
  chrome.tabs.sendMessage(tab.id, { type: 'FILL_BUKTI_DUKUNG', payload: { nama: bd.nama, link: bd.link } }, (r) => {
    if (chrome.runtime.lastError || r?.error) showToast(`❌ ${r?.error || 'Gagal mengisi.'}`, 'error');
    else showToast(`✅ "${bd.nama}" berhasil diisi!`, 'success');
  });
}

async function fillRealisasi(period, rhkId) {
  const list = await getRHKData(period);
  const rhk = list.find((r) => r.id === rhkId);
  if (!rhk) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.includes('kinerja.bkn.go.id')) { showToast('❌ Buka halaman e-Kinerja terlebih dahulu.', 'error'); return; }

  // Sumber Data otomatis selalu mengikuti Nama Bukti Dukung pertama
  const sumberData = rhk.sumberData || rhk.buktiDukung?.[0]?.nama || '';

  chrome.tabs.sendMessage(tab.id, { type: 'FILL_REALISASI', payload: { realisasi: rhk.realisasi, sumberData } }, (r) => {
    if (chrome.runtime.lastError || r?.error) showToast(`❌ ${r?.error || 'Gagal mengisi.'}`, 'error');
    else showToast('✅ Realisasi & Sumber Data berhasil diisi!', 'success');
  });
}

// ══════════════════════════════════════════════════════════════════
// 8. SETTINGS & OTA UPDATES
// ══════════════════════════════════════════════════════════════════

const OFFICIAL_UPDATE_URL = 'https://raw.githubusercontent.com/papituls/ekin-helper/refs/heads/main/version.json';
let latestUpdateData = null;

function compareVersions(v1, v2) {
  const parts1 = String(v1).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const parts2 = String(v2).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const maxLen = Math.max(parts1.length, parts2.length);
  for (let i = 0; i < maxLen; i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 > p2) return 1;
    if (p1 < p2) return -1;
  }
  return 0;
}

async function checkForUpdates(silent = true) {
  const statusEl = $('#manual-update-status');
  if (!silent && statusEl) statusEl.textContent = 'Memeriksa...';

  try {
    const res = await fetch(OFFICIAL_UPDATE_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const currentVer = chrome.runtime.getManifest().version;

    if (data?.version && compareVersions(data.version, currentVer) > 0) {
      latestUpdateData = data;
      $('#update-version-tag').textContent = `v${data.version}`;
      $('#update-notes-text').textContent = data.notes || 'Pembaruan fitur baru tersedia.';
      $('#update-banner')?.classList.remove('hidden');

      if (!silent) {
        showToast(`🚀 Versi baru v${data.version} ditemukan!`, 'info', 4000);
        if (statusEl) statusEl.textContent = `Ada update: v${data.version}`;
      }
    } else {
      if (!silent) {
        showToast(`✅ Ekstensi Anda sudah versi terbaru (v${currentVer}).`, 'success');
        if (statusEl) statusEl.textContent = 'Sudah versi terbaru.';
      }
    }
  } catch (err) {
    log('Cek update:', err.message);
    if (!silent) {
      showToast(`❌ Gagal memeriksa update: ${err.message}`, 'error');
      if (statusEl) statusEl.textContent = 'Gagal memeriksa.';
    }
  }
}

function initUpdateChecker() {
  $('#btn-dismiss-update')?.addEventListener('click', () => {
    $('#update-banner')?.classList.add('hidden');
  });

  $('#btn-check-update-manual')?.addEventListener('click', () => {
    checkForUpdates(false);
  });

  $('#btn-download-update')?.addEventListener('click', async () => {
    if (!latestUpdateData?.download_url) {
      showToast('❌ URL unduhan pembaruan tidak ditemukan.', 'error');
      return;
    }

    const btn = $('#btn-download-update');
    const statusHint = $('#update-download-status');
    btn.disabled = true;
    if (statusHint) statusHint.textContent = 'Mengunduh...';

    try {
      chrome.downloads.download(
        {
          url: latestUpdateData.download_url,
          filename: 'ekin-helper-update.zip',
          conflictAction: 'overwrite',
          saveAs: false,
        },
        (downloadId) => {
          if (chrome.runtime.lastError || !downloadId) {
            btn.disabled = false;
            if (statusHint) statusHint.textContent = 'Gagal mengunduh.';
            showToast(`❌ Gagal unduh: ${chrome.runtime.lastError?.message}`, 'error');
            return;
          }

          const checkTimer = setInterval(() => {
            chrome.downloads.search({ id: downloadId }, ([item]) => {
              if (item?.state === 'complete') {
                clearInterval(checkTimer);
                btn.disabled = false;
                if (statusHint) statusHint.textContent = 'Unduhan selesai!';

                // Buka Windows Explorer langsung ke file zip tersebut
                chrome.downloads.show(downloadId);

                showToast('✅ Unduhan selesai! Windows Explorer terbuka. Klik 2x file update.bat di folder ekstensi.', 'success', 8000);
              } else if (item?.state === 'interrupted') {
                clearInterval(checkTimer);
                btn.disabled = false;
                if (statusHint) statusHint.textContent = 'Unduhan terputus.';
                showToast('❌ Unduhan terputus.', 'error');
              }
            });
          }, 500);
        }
      );
    } catch (err) {
      btn.disabled = false;
      if (statusHint) statusHint.textContent = 'Error: ' + err.message;
      showToast(`❌ Error: ${err.message}`, 'error');
    }
  });
}

async function initSettings() {
  const { settings } = await getStorage('settings');
  const s = settings || {};
  $('#setting-year').value = s.year || new Date().getFullYear();
  $('#setting-name').value = s.name || '';
  $('#setting-nip').value = s.nip || '';
  $('#setting-auto-sumber').checked = s.autoSumber !== false;
  $('#btn-settings').addEventListener('click', () => $('#modal-settings').classList.remove('hidden'));
  $('#btn-save-settings').addEventListener('click', async () => {
    await setStorage({
      settings: {
        year: parseInt($('#setting-year').value),
        name: $('#setting-name').value.trim(),
        nip: $('#setting-nip').value.trim(),
        autoSumber: $('#setting-auto-sumber').checked,
      },
    });
    $('#modal-settings').classList.add('hidden');
    showToast('✅ Pengaturan tersimpan!', 'success');
  });
}

function initModals() {
  $$('.modal-close').forEach((btn) => {
    btn.addEventListener('click', () => document.getElementById(btn.dataset.modal)?.classList.add('hidden'));
  });
  $$('.modal').forEach((modal) => {
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.add('hidden'); });
  });
}

function initResetAll() {
  $('#btn-reset-all').addEventListener('click', async () => {
    if (!await confirmDialog('⚠️ Reset Semua Data', 'Semua data lokal akan dihapus. Koneksi Drive tetap aman.')) return;
    await new Promise((r) => chrome.storage.local.clear(r));
    showToast('🗑️ Data lokal dihapus.', 'error');
    refreshDriveTab(); renderRHKList(); renderTemplateList(); renderAutofillList();
  });
}

// ══════════════════════════════════════════════════════════════════
// 9. INIT
// ══════════════════════════════════════════════════════════════════

async function init() {
  initTabs();
  initModals();
  initResetAll();
  initAuth();
  initDriveTab();
  initRHKTab();
  initTemplateTab();
  initBatchAutoFill();
  initUpdateChecker();
  $('#autofill-period-select').addEventListener('change', renderAutofillList);
  await initSettings();
  await refreshDriveTab();
  setTimeout(() => checkForUpdates(true), 1500);
}

document.addEventListener('DOMContentLoaded', init);
