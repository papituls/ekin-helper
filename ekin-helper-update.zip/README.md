# 🏛️ Asisten e-Kinerja BKN

**Google Chrome Extension (Manifest V3)**  
Asisten pengisian otomatis e-Kinerja BKN (`kinerja.bkn.go.id`) dengan integrasi Google Drive.

---

## ✨ Fitur Utama

| Fitur | Deskripsi |
|-------|-----------|
| 📁 **Ekstrak Drive** | Baca nama & link berkas/folder dari Google Drive otomatis |
| 📋 **Manajemen RHK** | Kelola daftar RHK beserta bukti dukung per triwulan |
| 💾 **Template** | Simpan & salin konfigurasi antar triwulan (TW1–TW4 + Tahunan) |
| ⚡ **Auto-Fill** | Isi otomatis form Bukti Dukung & Realisasi di e-Kinerja |
| 📤 **Export/Import** | Backup & restore semua data dalam format JSON |

---

## 📂 Struktur File

```
ekin helper/
├── manifest.json          ← Manifest V3 (permissions, content scripts)
├── background.js          ← Service Worker (pesan & routing)
├── sidepanel.html         ← Antarmuka utama (4 tab)
├── sidepanel.css          ← Styling lengkap design system
├── sidepanel.js           ← Logika UI utama
├── content.js             ← Injeksi ke kinerja.bkn.go.id
├── content.css            ← Style overlay e-Kinerja
├── drive-content.js       ← Injeksi ke drive.google.com
├── generate_icons.py      ← Script pembuat icon PNG
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## 🚀 Cara Instalasi

1. Buka Chrome, pergi ke `chrome://extensions/`
2. Aktifkan **Developer mode** (pojok kanan atas)
3. Klik **"Load unpacked"**
4. Pilih folder `ekin helper/`
5. Ekstensi siap digunakan! Klik ikon **K** di toolbar.

---

## 🔄 Alur Penggunaan

### A. Ekstrak Berkas Google Drive

1. Buka Google Drive → navigasi ke **folder Triwulan** (misal: `Triwulan 1`)
2. Buka side panel ekstensi (klik ikon toolbar)
3. Tab **📁 Drive** → pilih periode (TW1–Tahunan)
4. Klik **"🔍 Ekstrak Folder Drive (Tab Aktif)"**
5. Data nama & link berkas tersimpan otomatis

> **Tip:** Gunakan **"📂 Ekstrak Sub-Folder RHK"** jika folder Triwulan berisi subfolder per RHK.

### B. Kelola RHK

1. Tab **📋 RHK** → pilih periode
2. Klik **"🔎 Deteksi dari Halaman"** saat membuka halaman e-Kinerja, atau
3. Klik **"📥 Import dari Data Drive"** untuk import dari hasil ekstraksi Drive
4. Edit tiap RHK: nama, bukti dukung, realisasi, sumber data

> **Catatan:** Sumber Data otomatis = Nama Bukti Dukung pertama (bisa diubah manual)

### C. Template Antar Triwulan

1. Tab **💾 Template** → pilih periode sumber
2. Klik **"💾 Simpan sebagai Template"** → beri nama
3. Di bagian bawah, pilih template → pilih periode target → klik **"✅ Terapkan"**
4. Centang *"Salin juga Link Drive"* jika link sama antar triwulan

### D. Auto-Fill e-Kinerja

1. Buka halaman penilaian triwulanan di `kinerja.bkn.go.id`
2. Tab **⚡ Auto-Fill** → pilih periode
3. **Bukti Dukung:** Klik "Tambah Bukti Dukung" di baris RHK → klik **📋 Bukti 1** di panel
4. **Realisasi:** Klik tombol realisasi di e-Kinerja → klik **📊 Realisasi** di panel

---

## 🔧 Penanganan Khusus Google Drive

### Pembersihan Teks Sampah
Script `drive-content.js` secara otomatis menghapus teks dari DOM Google Drive seperti:
- `More actions`, `More info`, `Shared folder`, `Folder bersama`
- `(Alt + →)`, tanggal, ukuran file, nama pemilik

### Deteksi Folder vs File
Menggunakan 4 strategi bertingkat:
1. `data-entrytype` attribute
2. `aria-label` mengandung kata "folder"
3. SVG icon title/desc
4. Class name patterns

### SPA Navigation Observer
Memantau perubahan URL Google Drive (Single Page App) tanpa reload halaman.

---

## 🛡️ Permissions

| Permission | Kegunaan |
|-----------|----------|
| `sidePanel` | Tampilan side panel Chrome |
| `storage` | Simpan data RHK & template lokal |
| `activeTab` | Akses tab yang sedang aktif |
| `scripting` | Injeksi script ke halaman |
| `tabs` | Query tab untuk routing pesan |
| `*://kinerja.bkn.go.id/*` | Akses halaman e-Kinerja |
| `*://drive.google.com/*` | Akses Google Drive |

---

## 💡 Tips & Troubleshooting

**Auto-fill tidak bekerja?**
- Pastikan modal sudah terbuka di e-Kinerja sebelum klik tombol auto-fill
- Jika e-Kinerja diperbarui, selector DOM mungkin berubah → laporkan di halaman Issues

**Ekstraksi Drive tidak mendeteksi berkas?**
- Tunggu halaman Drive selesai loading
- Coba pindah ke tampilan List (bukan Grid) di Drive
- Scroll ke bawah agar semua berkas ter-render di DOM

**Data hilang setelah update ekstensi?**
- Gunakan fitur **"📤 Export JSON"** sebelum update sebagai backup
- Import kembali setelah update selesai

---

## 📋 Format Data Internal

```json
{
  "rhkData": {
    "TW1": [
      {
        "id": "unique-id",
        "name": "Nama RHK",
        "order": 1,
        "buktiDukung": [
          { "nama": "Laporan Keuangan", "link": "https://drive.google.com/..." }
        ],
        "realisasi": "1 Laporan",
        "sumberData": "Laporan Keuangan"
      }
    ]
  },
  "driveTree": {
    "TW1": {
      "folderId": "abc123",
      "folderName": "Triwulan 1",
      "files": [...],
      "extractedAt": "2025-01-01T00:00:00Z"
    }
  },
  "templates": {
    "TW1 2025": { "period": "TW1", "rhkList": [...], "savedAt": "..." }
  }
}
```

---

*Dikembangkan untuk otomatisasi pengisian e-Kinerja BKN — menghemat waktu penilaian triwulanan ASN*
