// drive-api.js — Google Drive API v3 Engine
// Membaca struktur folder Drive secara resmi via OAuth token
// Tidak bergantung DOM — membaca SEMUA file meskipun tidak terlihat di layar
'use strict';

// ══════════════════════════════════════════════════════════════════
// KONFIGURASI & KONSTANTA
// ══════════════════════════════════════════════════════════════════

const DRIVE_API = 'https://www.googleapis.com/drive/v3';
const FOLDER_MIME = 'application/vnd.google-apps.folder';

// Fields yang diambil dari API (hemat kuota)
const FILE_FIELDS = 'id,name,mimeType,webViewLink,webContentLink,size,modifiedTime';
const LIST_FIELDS = `files(${FILE_FIELDS}),nextPageToken`;

// Pola pengenalan folder Triwulan/Tahunan (case-insensitive)
const PERIOD_PATTERNS = [
  { regex: /triwulan\s*1|tw\s*[_-]?\s*1\b/i,  key: 'TW1',     label: 'Triwulan 1' },
  { regex: /triwulan\s*2|tw\s*[_-]?\s*2\b/i,  key: 'TW2',     label: 'Triwulan 2' },
  { regex: /triwulan\s*3|tw\s*[_-]?\s*3\b/i,  key: 'TW3',     label: 'Triwulan 3' },
  { regex: /triwulan\s*4|tw\s*[_-]?\s*4\b/i,  key: 'TW4',     label: 'Triwulan 4' },
  { regex: /tahunan|annual|yearly/i,           key: 'Tahunan', label: 'Tahunan'    },
];

// Pola pengenalan folder RHK — ekstrak nomor urut
const RHK_NUMBER_PATTERN = /rhk\s*[_-]?\s*(\d+)/i;

// ══════════════════════════════════════════════════════════════════
// 1. AUTH — Ambil token dari sesi Chrome yang sudah login
// ══════════════════════════════════════════════════════════════════

/**
 * Ambil OAuth token menggunakan chrome.identity.launchWebAuthFlow
 * yang kompatibel penuh dengan Manifest V3 & Unpacked Extensions
 * tanpa terhalang 'Custom URI scheme is not supported'.
 *
 * @param {boolean} interactive - true = tampilkan popup jika perlu
 * @returns {Promise<string>} access token
 */
export async function getAuthToken(interactive = false) {
  // 1. Cek apakah ada token aktif yang masih valid di storage
  const stored = await new Promise((r) =>
    chrome.storage.local.get(['oauth_token', 'oauth_token_exp'], r)
  );

  if (stored.oauth_token && stored.oauth_token_exp && Date.now() < stored.oauth_token_exp) {
    return stored.oauth_token;
  }

  // Jika tidak interactive dan token expired/kosong, reject
  if (!interactive) {
    throw new Error('Belum login atau token telah kadaluarsa.');
  }

  // 2. Ambil client_id & scopes dari manifest
  const manifest = chrome.runtime.getManifest();
  const clientId = manifest.oauth2?.client_id;
  if (!clientId) {
    throw new Error('client_id belum dikonfigurasi di manifest.json');
  }

  const redirectUri = chrome.identity.getRedirectURL(); // https://<id>.chromiumapp.org/
  const scopes = encodeURIComponent(
    manifest.oauth2?.scopes?.join(' ') || 'https://www.googleapis.com/auth/drive.readonly'
  );

  const authUrl =
    `https://accounts.google.com/o/oauth2/v2/auth` +
    `?client_id=${encodeURIComponent(clientId)}` +
    `&response_type=token` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&scope=${scopes}` +
    `&prompt=consent`;

  return new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow(
      { url: authUrl, interactive: true },
      (responseUrl) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (!responseUrl) {
          reject(new Error('Login dibatalkan oleh pengguna.'));
          return;
        }

        // Ambil access_token dari fragment URL (#access_token=...&expires_in=...)
        const tokenMatch = responseUrl.match(/[#&]access_token=([^&]+)/);
        if (!tokenMatch) {
          const errMatch = responseUrl.match(/[?#&]error=([^&]+)/);
          const errDesc = responseUrl.match(/[?#&]error_description=([^&]+)/);
          const msg = errDesc ? decodeURIComponent(errDesc[1]) : (errMatch ? errMatch[1] : 'Token tidak ditemukan');
          reject(new Error(`Otorisasi gagal: ${msg}`));
          return;
        }

        const token = decodeURIComponent(tokenMatch[1]);
        const expMatch = responseUrl.match(/[#&]expires_in=([^&]+)/);
        const expiresInSec = expMatch ? parseInt(expMatch[1], 10) : 3600;

        // Simpan ke storage (dikurangi buffer 2 menit)
        chrome.storage.local.set({
          oauth_token: token,
          oauth_token_exp: Date.now() + (expiresInSec - 120) * 1000,
        });

        resolve(token);
      }
    );
  });
}

/**
 * Hapus token dari cache lokal dan cabut otorisasi.
 */
export async function revokeToken(token) {
  await new Promise((r) => chrome.storage.local.remove(['oauth_token', 'oauth_token_exp'], r));

  if (token) {
    try {
      await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(token)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
    } catch (_) {}
    if (chrome.identity.removeCachedAuthToken) {
      chrome.identity.removeCachedAuthToken({ token }, () => {});
    }
  }
}

// ══════════════════════════════════════════════════════════════════
// 2. API FETCH HELPER
// ══════════════════════════════════════════════════════════════════

/**
 * Fetch ke Drive API dengan auto-refresh token jika 401.
 */
async function apiFetch(url, token, retried = false) {
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (res.status === 401 && !retried) {
    // Token expired → hapus cache → minta token baru → coba lagi
    await revokeToken(token);
    const newToken = await getAuthToken(false);
    return apiFetch(url, newToken, true);
  }

  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    throw new Error(`Drive API error ${res.status}: ${errBody?.error?.message || res.statusText}`);
  }

  return res.json();
}

// ══════════════════════════════════════════════════════════════════
// 3. LIST FILES — Ambil semua item dalam sebuah folder
// ══════════════════════════════════════════════════════════════════

/**
 * List semua file & subfolder dalam folder dengan ID tertentu.
 * Otomatis handle pagination (jika folder berisi >1000 item).
 *
 * @param {string} folderId
 * @param {string} token
 * @returns {Promise<Array>} array of file objects
 */
async function listFolderItems(folderId, token) {
  const items = [];
  let pageToken = null;

  do {
    const query = encodeURIComponent(`'${folderId}' in parents and trashed = false`);
    let url = `${DRIVE_API}/files?q=${query}&fields=${encodeURIComponent(LIST_FIELDS)}&pageSize=1000&orderBy=name`;
    if (pageToken) url += `&pageToken=${pageToken}`;

    const data = await apiFetch(url, token);
    items.push(...(data.files || []));
    pageToken = data.nextPageToken || null;
  } while (pageToken);

  return items;
}

// ══════════════════════════════════════════════════════════════════
// 4. HELPER — KLASIFIKASI ITEM
// ══════════════════════════════════════════════════════════════════

function isFolder(item) {
  return item.mimeType === FOLDER_MIME;
}

/**
 * Buat URL yang bisa diklik untuk file/folder Drive.
 */
function buildUrl(item) {
  if (isFolder(item)) {
    return `https://drive.google.com/drive/folders/${item.id}`;
  }
  // webViewLink sudah disediakan API untuk file
  return item.webViewLink || `https://drive.google.com/file/d/${item.id}/view`;
}

/**
 * Deteksi apakah nama folder sesuai pola Triwulan/Tahunan.
 * @returns {{ key, label } | null}
 */
function matchPeriod(name) {
  for (const p of PERIOD_PATTERNS) {
    if (p.regex.test(name)) return { key: p.key, label: p.label };
  }
  return null;
}

/**
 * Deteksi nomor RHK dari nama folder.
 * Contoh: "RHK 1", "RHK-2", "rhk_03" → 1, 2, 3
 * Nama non-RHK (mis. "Bangkom") → null (tetap masuk sebagai RHK tanpa nomor)
 */
function extractRhkOrder(name) {
  const m = name.match(RHK_NUMBER_PATTERN);
  return m ? parseInt(m[1], 10) : null;
}

/**
 * Tentukan ikon berdasarkan mimeType.
 */
export function mimeIcon(mimeType) {
  if (!mimeType) return '📄';
  if (mimeType === FOLDER_MIME) return '📁';
  if (mimeType.includes('pdf')) return '📕';
  if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return '📗';
  if (mimeType.includes('document') || mimeType.includes('word')) return '📘';
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return '📙';
  if (mimeType.includes('image')) return '🖼️';
  if (mimeType.includes('video')) return '🎬';
  if (mimeType.includes('audio')) return '🎵';
  if (mimeType.includes('zip') || mimeType.includes('compressed')) return '📦';
  return '📄';
}

// ══════════════════════════════════════════════════════════════════
// 5. EKSTRAK ID DARI URL
// ══════════════════════════════════════════════════════════════════

/**
 * Ekstrak folder ID dari berbagai format URL Google Drive.
 * Mendukung:
 *   - https://drive.google.com/drive/folders/FOLDER_ID
 *   - https://drive.google.com/drive/folders/FOLDER_ID?usp=sharing
 *   - https://drive.google.com/open?id=FOLDER_ID
 *   - FOLDER_ID langsung (jika user paste ID-nya saja)
 */
export function extractFolderId(input) {
  if (!input) return null;
  input = input.trim();

  // Pola URL folder
  const folderMatch = input.match(/\/folders\/([a-zA-Z0-9_-]{10,})/);
  if (folderMatch) return folderMatch[1];

  // Pola open?id=
  const openMatch = input.match(/[?&]id=([a-zA-Z0-9_-]{10,})/);
  if (openMatch) return openMatch[1];

  // Jika sudah berbentuk ID murni (hanya alfanumerik & - _)
  if (/^[a-zA-Z0-9_-]{10,}$/.test(input)) return input;

  return null;
}

// ══════════════════════════════════════════════════════════════════
// 6. SCAN RHK FOLDER — Baca file & subfolder dalam satu RHK
// ══════════════════════════════════════════════════════════════════

/**
 * Baca isi folder RHK:
 * - File langsung → masuk sebagai item
 * - Sub-folder → masuk sebagai item type=folder SEKALIGUS baca isinya
 *
 * Struktur hasil:
 * {
 *   type: 'file'|'folder',
 *   name: string,
 *   id: string,
 *   url: string,
 *   mimeType: string,
 *   // hanya untuk type='folder':
 *   files: [ { type:'file', name, id, url, mimeType } ]
 * }
 */
async function scanRhkFolder(folderId, token, onProgress) {
  const items = await listFolderItems(folderId, token);
  const result = [];

  for (const item of items) {
    if (isFolder(item)) {
      // Sub-folder: masuk ke dalamnya untuk ambil file-nya
      onProgress?.(`  📂 Membaca sub-folder: ${item.name}`);
      const subFiles = await listFolderItems(item.id, token);

      result.push({
        type: 'folder',
        name: item.name,
        id: item.id,
        url: buildUrl(item),
        mimeType: FOLDER_MIME,
        files: subFiles
          .filter((f) => !isFolder(f)) // Hanya ambil file (tidak rekursi lebih dalam)
          .map((f) => ({
            type: 'file',
            name: f.name,
            id: f.id,
            url: buildUrl(f),
            mimeType: f.mimeType || '',
          })),
      });
    } else {
      // File langsung
      result.push({
        type: 'file',
        name: item.name,
        id: item.id,
        url: buildUrl(item),
        mimeType: item.mimeType || '',
      });
    }
  }

  // Urutkan: file dulu, lalu folder
  result.sort((a, b) => {
    if (a.type === b.type) return a.name.localeCompare(b.name, 'id');
    return a.type === 'file' ? -1 : 1;
  });

  return result;
}

// ══════════════════════════════════════════════════════════════════
// 7. SCAN PERIODE — Baca semua RHK dalam satu Triwulan/Tahunan
// ══════════════════════════════════════════════════════════════════

/**
 * Baca semua RHK dalam folder periode (Triwulan/Tahunan).
 *
 * Hasil:
 * [
 *   {
 *     rhkId: 'RHK 1',
 *     rhkName: 'RHK 1',
 *     rhkOrder: 1,
 *     folderId: '...',
 *     folderUrl: '...',
 *     items: [ ...hasil scanRhkFolder... ]
 *   },
 *   ...
 * ]
 */
async function scanPeriodFolder(periodFolderId, token, onProgress) {
  const items = await listFolderItems(periodFolderId, token);
  const rhkFolders = items.filter(isFolder);

  if (rhkFolders.length === 0) {
    // Tidak ada subfolder RHK — anggap file-file di sini langsung adalah items
    onProgress?.('  ⚠️ Tidak ada subfolder RHK, membaca file langsung.');
    const files = items.filter((i) => !isFolder(i)).map((f) => ({
      type: 'file',
      name: f.name,
      id: f.id,
      url: buildUrl(f),
      mimeType: f.mimeType || '',
    }));
    return [{
      rhkId: 'langsung',
      rhkName: '(File Langsung)',
      rhkOrder: 0,
      folderId: periodFolderId,
      folderUrl: `https://drive.google.com/drive/folders/${periodFolderId}`,
      items: files,
    }];
  }

  // Klasifikasi & urutkan folder RHK
  const rhkList = rhkFolders.map((f) => ({
    raw: f,
    order: extractRhkOrder(f.name) ?? 9999,
  }));

  // Urutkan: RHK bernomor duluan (urut angka), lalu non-RHK urut nama
  rhkList.sort((a, b) => a.order !== b.order
    ? a.order - b.order
    : a.raw.name.localeCompare(b.raw.name, 'id'));

  const result = [];
  for (const { raw, order } of rhkList) {
    onProgress?.(`📂 Membaca RHK: ${raw.name}`);
    const items = await scanRhkFolder(raw.id, token, onProgress);
    result.push({
      rhkId: raw.id,
      rhkName: raw.name,
      rhkOrder: order === 9999 ? null : order,
      folderId: raw.id,
      folderUrl: buildUrl(raw),
      items,
    });
  }

  return result;
}

// ══════════════════════════════════════════════════════════════════
// 8. SCAN ROOT — Entry point utama
// ══════════════════════════════════════════════════════════════════

/**
 * Scan seluruh pohon folder dari folder induk.
 *
 * @param {string} rootFolderId  - ID folder induk
 * @param {string} token         - OAuth access token
 * @param {Function} onProgress  - callback (message: string) untuk update UI
 * @param {Array} targetPeriods  - ['TW1','TW2',...] atau null untuk semua
 *
 * Hasil yang disimpan ke storage:
 * {
 *   TW1: {
 *     periodKey: 'TW1',
 *     periodLabel: 'Triwulan 1',
 *     folderId: '...',
 *     folderUrl: '...',
 *     rhkList: [ ...hasil scanPeriodFolder... ],
 *     scannedAt: ISO string
 *   },
 *   TW2: { ... },
 *   ...
 * }
 */
export async function scanRootFolder(rootFolderId, token, onProgress, targetPeriods = null) {
  onProgress?.('🔍 Membaca daftar folder di folder induk...');

  // Ambil semua item di root
  const rootItems = await listFolderItems(rootFolderId, token);
  const periodFolders = rootItems.filter(isFolder);

  if (periodFolders.length === 0) {
    throw new Error('Folder induk tidak berisi subfolder. Pastikan folder yang benar sudah dipilih.');
  }

  const result = {};

  for (const folder of periodFolders) {
    const match = matchPeriod(folder.name);
    if (!match) {
      onProgress?.(`⏭️ Skip "${folder.name}" — tidak dikenali sebagai Triwulan/Tahunan`);
      continue;
    }

    // Filter berdasarkan periode yang diminta
    if (targetPeriods && !targetPeriods.includes(match.key)) {
      onProgress?.(`⏭️ Skip ${match.label} (tidak dipilih)`);
      continue;
    }

    onProgress?.(`\n📅 Memproses ${match.label}...`);

    const rhkList = await scanPeriodFolder(folder.id, token, onProgress);

    result[match.key] = {
      periodKey: match.key,
      periodLabel: match.label,
      folderId: folder.id,
      folderUrl: buildUrl(folder),
      rhkList,
      scannedAt: new Date().toISOString(),
    };
  }

  if (Object.keys(result).length === 0) {
    throw new Error(
      'Tidak ada folder Triwulan/Tahunan yang dikenali. ' +
      'Pastikan nama folder sesuai standar: "Triwulan 1", "Triwulan 2", dst.'
    );
  }

  return result;
}

// ══════════════════════════════════════════════════════════════════
// 9. HELPER — Info folder root (nama folder dari ID)
// ══════════════════════════════════════════════════════════════════

export async function getFolderInfo(folderId, token) {
  const url = `${DRIVE_API}/files/${folderId}?fields=id,name,mimeType,webViewLink`;
  const data = await apiFetch(url, token);
  return {
    id: data.id,
    name: data.name,
    url: data.webViewLink || `https://drive.google.com/drive/folders/${data.id}`,
    isFolder: data.mimeType === FOLDER_MIME,
  };
}
