// drive-content.js — Diinjeksi ke drive.google.com
// Tugas: Ekstrak nama & link berkas/folder dari tampilan Google Drive
'use strict';

// ──────────────────────────────────────────────
// CONSTANTS
// ──────────────────────────────────────────────

// Teks sampah yang harus dibersihkan dari nama berkas di DOM Google Drive
const GARBAGE_PATTERNS = [
  /More actions/gi,
  /More info/gi,
  /Shared folder/gi,
  /Folder bersama/gi,
  /Alt \+ →/gi,
  /\(Alt \+.*?\)/gi,
  /Owner/gi,
  /Pemilik/gi,
  /Last modified/gi,
  /Terakhir diubah/gi,
  /File size/gi,
  /Ukuran file/gi,
  /\d{1,2} [A-Za-z]{3} \d{4}/g,   // tanggal seperti "1 Jan 2025"
  /\d+(\.\d+)? (KB|MB|GB|TB)/gi,  // ukuran file
  /you/gi,
];

function cleanName(text) {
  if (!text) return '';
  let clean = text;
  GARBAGE_PATTERNS.forEach((p) => { clean = clean.replace(p, ''); });
  return clean.replace(/\s+/g, ' ').trim();
}

function log(...args) {
  console.log('[Drive-Helper]', ...args);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// ──────────────────────────────────────────────
// DETEKSI: Apakah item adalah Folder atau File
// ──────────────────────────────────────────────

function isFolder(rowEl) {
  // Periksa atribut aria-label / data-type / ikon folder
  const label = (rowEl.getAttribute('aria-label') || '').toLowerCase();
  const dataEntryType = rowEl.dataset.entrytype || '';
  const title = rowEl.getAttribute('title') || '';

  if (dataEntryType.toLowerCase() === 'folder') return true;
  if (label.includes('folder')) return true;
  if (title.toLowerCase().includes('folder')) return true;

  // Periksa ikon SVG: ikon folder Google Drive biasanya mengandung path khas
  const svg = rowEl.querySelector('svg');
  if (svg) {
    const svgTitle = svg.querySelector('title, desc')?.textContent?.toLowerCase() || '';
    if (svgTitle.includes('folder')) return true;
  }

  // Periksa class ikon
  const iconEl = rowEl.querySelector('[aria-label*="folder" i], [data-icon*="folder" i], .folder-icon');
  if (iconEl) return true;

  return false;
}

// ──────────────────────────────────────────────
// EKSTRAK ID DARI URL Google Drive
// ──────────────────────────────────────────────

function extractDriveId(url) {
  if (!url) return null;
  // Format: /drive/folders/ID atau /file/d/ID/view atau /open?id=ID
  const patterns = [
    /\/folders\/([a-zA-Z0-9_-]{25,})/,
    /\/file\/d\/([a-zA-Z0-9_-]{25,})/,
    /[?&]id=([a-zA-Z0-9_-]{25,})/,
    /\/d\/([a-zA-Z0-9_-]{25,})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

function buildFolderUrl(id) {
  return `https://drive.google.com/drive/folders/${id}`;
}

function buildFileUrl(id) {
  return `https://drive.google.com/file/d/${id}/view`;
}

// ──────────────────────────────────────────────
// EKSTRAK BERKAS DARI TAMPILAN GRID/LIST
// ──────────────────────────────────────────────

function extractFromCurrentView() {
  const results = [];

  // ── Strategi 1: Baris tabel (tampilan List) ──
  const listRows = document.querySelectorAll('[role="row"]:not([role="columnheader"])');
  if (listRows.length > 0) {
    log(`Ditemukan ${listRows.length} baris list.`);
    listRows.forEach((row) => {
      const fileInfo = extractFromRow(row);
      if (fileInfo) results.push(fileInfo);
    });
    if (results.length > 0) return results;
  }

  // ── Strategi 2: Grid items (tampilan Grid) ──
  const gridItems = document.querySelectorAll('[role="gridcell"] [data-id], .KF4T6b, [data-target="FILE"]');
  if (gridItems.length > 0) {
    log(`Ditemukan ${gridItems.length} grid items.`);
    gridItems.forEach((item) => {
      const fileInfo = extractFromGridItem(item);
      if (fileInfo) results.push(fileInfo);
    });
    if (results.length > 0) return results;
  }

  // ── Strategi 3: Anchor links ke berkas/folder Drive ──
  const driveLinks = document.querySelectorAll('a[href*="drive.google.com/file"], a[href*="/file/d/"], a[href*="/folders/"]');
  if (driveLinks.length > 0) {
    log(`Ditemukan ${driveLinks.length} tautan Drive.`);
    driveLinks.forEach((a) => {
      const name = cleanName(a.textContent || a.title || a.getAttribute('aria-label') || '');
      const url = a.href;
      const id = extractDriveId(url);
      const folder = url.includes('/folders/');
      if (name && id) {
        results.push({ name, url, id, type: folder ? 'folder' : 'file' });
      }
    });
  }

  // ── Strategi 4: Drive list items via data-id ──
  const dataItems = document.querySelectorAll('[data-id]');
  dataItems.forEach((item) => {
    const id = item.dataset.id;
    if (!id || id.length < 10) return;
    // Coba cari nama
    const nameEl = item.querySelector('[class*="name"], [aria-label], .KL4NAf, .k0Jjg');
    const name = cleanName(nameEl?.textContent || item.getAttribute('aria-label') || '');
    if (!name) return;
    const folder = isFolder(item);
    const url = folder ? buildFolderUrl(id) : buildFileUrl(id);
    if (!results.some((r) => r.id === id)) {
      results.push({ name, url, id, type: folder ? 'folder' : 'file' });
    }
  });

  return results;
}

/**
 * Ekstrak info berkas dari baris list ([role="row"])
 */
function extractFromRow(row) {
  // Nama berkas
  const nameSelectors = [
    '[data-tooltip]', '.KL4NAf', '.k0Jjg',
    '[role="gridcell"]:nth-child(2)', '[aria-label]',
    '.eo8Fnd', '.WYuW0e', '[class*="filename"]',
  ];

  let name = '';
  for (const sel of nameSelectors) {
    const el = row.querySelector(sel);
    if (el) {
      name = cleanName(el.getAttribute('data-tooltip') || el.textContent || el.getAttribute('aria-label') || '');
      if (name) break;
    }
  }

  if (!name) {
    name = cleanName(row.getAttribute('aria-label') || row.getAttribute('data-tooltip') || '');
  }

  if (!name) return null;

  // ID / URL
  const id = row.dataset.id || row.dataset.entryId || '';
  const folder = isFolder(row);
  const url = id ? (folder ? buildFolderUrl(id) : buildFileUrl(id)) : '';

  // Juga cek jika ada link langsung
  const link = row.querySelector('a[href*="drive.google.com"], a[href*="/file/d/"], a[href*="/folders/"]');
  const finalUrl = link?.href || url;

  if (!name) return null;

  return {
    name,
    url: finalUrl,
    id: id || extractDriveId(finalUrl) || '',
    type: folder ? 'folder' : 'file',
    rhkFolder: getCurrentFolderName(),
  };
}

/**
 * Ekstrak info berkas dari item grid
 */
function extractFromGridItem(item) {
  const name = cleanName(
    item.getAttribute('aria-label') ||
    item.getAttribute('data-tooltip') ||
    item.querySelector('[class*="name"], .KL4NAf')?.textContent || ''
  );
  if (!name) return null;

  const id = item.dataset.id || item.closest('[data-id]')?.dataset.id || '';
  const folder = isFolder(item);
  const url = id ? (folder ? buildFolderUrl(id) : buildFileUrl(id)) : '';

  return { name, url, id, type: folder ? 'folder' : 'file', rhkFolder: getCurrentFolderName() };
}

/**
 * Ambil nama folder yang sedang ditampilkan dari breadcrumb
 */
function getCurrentFolderName() {
  // Breadcrumb Google Drive
  const breadcrumbSelectors = [
    '.Q5txwe .WT3SK', '.a-b-s-Ma-pb:last-child', '[data-tooltip]',
    '.l9Y6re.CeoRYc', '.Kj1bNb:last-child', 'h1', '.breadcrumb li:last-child',
    '[aria-label="breadcrumb"] li:last-child',
  ];
  for (const sel of breadcrumbSelectors) {
    const el = document.querySelector(sel);
    if (el) {
      const text = cleanName(el.textContent || el.getAttribute('aria-label') || '');
      if (text && text.length > 1) return text;
    }
  }
  return document.title.replace(' - Google Drive', '').trim() || 'Root';
}

/**
 * Ambil folder ID dari URL saat ini
 */
function getCurrentFolderId() {
  return extractDriveId(window.location.href) || null;
}

// ──────────────────────────────────────────────
// EKSTRAK BERKAS + TUNGGU LOADING SELESAI
// ──────────────────────────────────────────────

async function extractWithWait(retries = 3) {
  for (let i = 0; i < retries; i++) {
    await sleep(800 + i * 500);
    const files = extractFromCurrentView();
    if (files.length > 0) return files;
    log(`Percobaan ke-${i + 1}: belum ada berkas ditemukan.`);
  }
  return [];
}

// ──────────────────────────────────────────────
// MESSAGE LISTENER
// ──────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;

  switch (type) {

    // ── Ekstrak semua berkas di tampilan saat ini ──
    case 'EXTRACT_FILES': {
      const period = payload?.period || 'TW1';
      const folderName = getCurrentFolderName();
      const folderId = getCurrentFolderId();

      extractWithWait().then((files) => {
        log(`Ekstraksi selesai: ${files.length} berkas ditemukan.`);

        chrome.runtime.sendMessage({
          type: 'DRIVE_FILES_EXTRACTED',
          payload: { period, folderId, folderName, files }
        }, () => {
          sendResponse({ success: true, count: files.length, files });
        });
      });

      return true; // async
    }

    // ── Ekstrak subfolder (masuk ke tiap folder RHK) ──
    case 'EXTRACT_SUBFOLDER_FILES': {
      const period = payload?.period || 'TW1';
      extractSubfolderFiles(period).then((result) => {
        sendResponse(result);
      });
      return true;
    }

    case 'PING': {
      sendResponse({ alive: true, url: window.location.href });
      break;
    }

    default:
      break;
  }
});

// ──────────────────────────────────────────────
// EKSTRAK SUBFOLDER (untuk navigasi otomatis)
// ──────────────────────────────────────────────

async function extractSubfolderFiles(period) {
  // Ambil dulu semua item di folder saat ini
  await sleep(800);
  const items = extractFromCurrentView();
  log('Items di folder saat ini:', items);

  const folders = items.filter((i) => i.type === 'folder');
  const directFiles = items.filter((i) => i.type !== 'folder');

  if (folders.length === 0) {
    // Tidak ada subfolder, simpan langsung
    chrome.runtime.sendMessage({
      type: 'DRIVE_FILES_EXTRACTED',
      payload: {
        period,
        folderId: getCurrentFolderId(),
        folderName: getCurrentFolderName(),
        files: directFiles
      }
    });
    return { success: true, count: directFiles.length };
  }

  // Ada subfolder: simpan nama + link folder sebagai "bukti dukung"
  // Ini adalah pola umum: level 2 (folder RHK) → gunakan folder-link sebagai bukti
  const allFiles = [...directFiles];
  folders.forEach((folder) => {
    allFiles.push({
      name: folder.name,
      url: folder.url,
      id: folder.id,
      type: 'folder',
      rhkFolder: getCurrentFolderName(),
    });
  });

  chrome.runtime.sendMessage({
    type: 'DRIVE_FILES_EXTRACTED',
    payload: {
      period,
      folderId: getCurrentFolderId(),
      folderName: getCurrentFolderName(),
      files: allFiles
    }
  });

  return { success: true, count: allFiles.length };
}

// ──────────────────────────────────────────────
// SPA NAVIGATION OBSERVER
// Deteksi navigasi Google Drive (SPA) agar ekstraksi bisa dilakukan
// tanpa reload halaman
// ──────────────────────────────────────────────

let lastUrl = window.location.href;

function initNavigationObserver() {
  // Pantau perubahan URL (SPA navigation)
  const observer = new MutationObserver(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      log('Navigasi SPA terdeteksi:', lastUrl);
      // Kirim notifikasi ke extension bahwa halaman berubah
      chrome.runtime.sendMessage({
        type: 'DRIVE_NAVIGATION',
        payload: { url: lastUrl, folderName: getCurrentFolderName(), folderId: getCurrentFolderId() }
      }).catch(() => {});
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// ──────────────────────────────────────────────
// INIT
// ──────────────────────────────────────────────

log('Drive content script aktif di:', window.location.href);
initNavigationObserver();
