// content.js — Diinjeksi ke kinerja.bkn.go.id
// Tugas: Deteksi tabel RHK e-Kinerja BKN secara presisi & Auto-Fill form Bukti Dukung & Realisasi
'use strict';

function log(...args) {
  console.log('[eKinerja-Helper]', ...args);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Tunggu hingga elemen ditemukan di DOM (dengan timeout).
 */
function waitForElement(selector, timeout = 4000, root = document) {
  return new Promise((resolve, reject) => {
    const found = root.querySelector(selector);
    if (found) { resolve(found); return; }

    const obs = new MutationObserver(() => {
      const el = root.querySelector(selector);
      if (el) { obs.disconnect(); resolve(el); }
    });
    obs.observe(root.body || root, { childList: true, subtree: true });

    setTimeout(() => {
      obs.disconnect();
      reject(new Error(`Timeout: "${selector}" tidak ditemukan dalam ${timeout}ms`));
    }, timeout);
  });
}

/**
 * Isi nilai input/textarea dan picu event React/Vue/Angular/Bootstrap secara sempurna.
 */
function setNativeValue(el, value) {
  if (!el || value === undefined || value === null) return;
  const prototype = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  const nativeSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;

  el.focus();
  if (nativeSetter) {
    nativeSetter.call(el, value);
  } else {
    el.value = value;
  }

  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
  el.dispatchEvent(new Event('blur', { bubbles: true }));

  // Visual highlight efek hijau saat diisi
  el.classList.add('ekinerja-helper-highlight');
  setTimeout(() => el.classList.remove('ekinerja-helper-highlight'), 3000);
}

// ──────────────────────────────────────────────
// DETEKSI RHK DARI TABEL e-Kinerja BKN
// ──────────────────────────────────────────────

function detectRHK() {
  const results = [];

  // Cari tabel yang berisi kolom "BUKTI DUKUNG" dan "RENCANA HASIL KERJA"
  const tables = [...document.querySelectorAll('table')];
  const targetTable = tables.find((t) => {
    const text = t.textContent.toUpperCase();
    return text.includes('BUKTI DUKUNG') && text.includes('RENCANA HASIL KERJA');
  }) || tables.find((t) => t.textContent.toUpperCase().includes('RENCANA HASIL KERJA'));

  if (!targetTable) {
    log('Tabel RHK tidak ditemukan pada halaman ini.');
    return [];
  }

  log('Tabel RHK ditemukan:', targetTable);

  const rows = [...targetTable.querySelectorAll('tr')];

  // Identifikasi letak indeks kolom dari baris header
  let rhkColIdx = 2; // Default kolom ke-3 (indeks 2) pada e-Kinerja BKN
  let noColIdx = 0;

  for (let r = 0; r < Math.min(rows.length, 4); r++) {
    const headers = [...rows[r].querySelectorAll('th, td')];
    for (let c = 0; c < headers.length; c++) {
      const hText = headers[c].textContent.trim().toUpperCase().replace(/\s+/g, ' ');
      if (hText === 'NO' || hText === 'NO.') {
        noColIdx = c;
      } else if (
        hText.includes('RENCANA HASIL KERJA') &&
        !hText.includes('PIMPINAN') &&
        !hText.includes('INTERVENSI')
      ) {
        rhkColIdx = c;
        log(`Indeks kolom RHK terdeteksi di kolom ke-${c + 1} (indeks ${c})`);
      }
    }
  }

  let runningOrder = 1;

  for (const row of rows) {
    const cells = [...row.querySelectorAll('td, th')];
    if (cells.length < 5) continue; // Skip baris pendek/header colspan (seperti "Utama", "Tambahan")

    // Baris RHK valid di e-Kinerja BKN memiliki ciri:
    // 1. Kolom pertama berisi angka nomor urut (misal: "1", "2", "3")
    // ATAU
    // 2. Baris tersebut memiliki tombol "Tambah" hijau pada kolom Bukti Dukung
    const firstCellText = cells[noColIdx]?.textContent.trim() || cells[0]?.textContent.trim() || '';
    const hasOrderNumber = /^\d+$/.test(firstCellText);
    const hasTambahButton = [...row.querySelectorAll('button, a, span')].some(
      (btn) => btn.textContent.trim().toLowerCase() === 'tambah'
    );

    if (!hasOrderNumber && !hasTambahButton) {
      continue; // Lewati baris judul kategori seperti "Utama", "Tambahan", "RATING", dsb
    }

    // Ambil isi teks RHK dari kolom RHK
    let targetCell = cells[rhkColIdx];
    if (!targetCell && cells.length > 2) {
      targetCell = cells[2];
    }
    if (!targetCell) continue;

    let rhkText = (targetCell.innerText || targetCell.textContent || '').trim().replace(/\s+/g, ' ');

    // Pastikan bukan teks header yang lolos
    if (
      !rhkText ||
      rhkText.length < 5 ||
      rhkText.toUpperCase() === 'RENCANA HASIL KERJA' ||
      rhkText.toUpperCase().includes('PIMPINAN YANG DIINTERVENSI')
    ) {
      continue;
    }

    // Nomor urut
    let orderNum = parseInt(firstCellText, 10);
    if (isNaN(orderNum) || orderNum <= 0) {
      orderNum = runningOrder;
    }
    runningOrder = orderNum + 1;

    // Hindari duplikasi jika ada baris yang berulang
    if (!results.some((x) => x.name.toLowerCase() === rhkText.toLowerCase())) {
      results.push({
        order: orderNum,
        name: rhkText,
      });
      log(`RHK terdeteksi: #${orderNum} - ${rhkText}`);
    }
  }

  results.sort((a, b) => a.order - b.order);
  return results;
}

// ──────────────────────────────────────────────
// AUTO-FILL: BUKTI DUKUNG
// ──────────────────────────────────────────────

async function fillBuktiDukung({ nama, link }) {
  // 1. Cari modal yang sedang aktif/terbuka di halaman
  const modalSelectors = [
    '.modal.show',
    '.modal[style*="display: block"]',
    '[role="dialog"]:not([aria-hidden="true"])',
    '.swal2-modal',
  ];

  let modal = null;
  for (const sel of modalSelectors) {
    modal = document.querySelector(sel);
    if (modal) break;
  }

  if (!modal) {
    try {
      modal = await waitForElement('.modal.show, [role="dialog"]:not([aria-hidden="true"])', 4000);
    } catch {
      return {
        error: 'Modal Bukti Dukung belum terbuka di halaman e-Kinerja. Silakan klik tombol "Tambah" hijau pada baris RHK terlebih dahulu.',
      };
    }
  }

  log('Modal Bukti Dukung aktif:', modal);

  // Cari semua input teks di dalam modal body
  const allInputs = [
    ...modal.querySelectorAll(
      'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), textarea'
    ),
  ];

  let namaInput = null;
  let linkInput = null;

  // Metode A: Cek berdasarkan teks label di sekitarnya
  const labels = [...modal.querySelectorAll('label, .form-label, strong, span, p')];
  for (const label of labels) {
    const lText = label.textContent.trim().toUpperCase();
    const parent = label.closest('.form-group, .mb-3, .form-row, .row, div');
    const input = parent?.querySelector('input:not([type="hidden"]), textarea');

    if (input) {
      if (lText.includes('NAMA BUKTI') || (lText.includes('NAMA') && !lText.includes('PEGAWAI'))) {
        namaInput = input;
      } else if (lText.includes('LINK') || lText.includes('DROPBOX') || lText.includes('BUKTI DUKUNG (LINK') || lText.includes('TAUTAN')) {
        linkInput = input;
      }
    }
  }

  // Metode B: Fallback berdasarkan urutan input modal e-Kinerja:
  // Input 0 = NAMA BUKTI DUKUNG
  // Input 1 = BUKTI DUKUNG (LINK)
  if (!namaInput && allInputs.length > 0) namaInput = allInputs[0];
  if (!linkInput && allInputs.length > 1) linkInput = allInputs[1];

  let filledCount = 0;

  if (namaInput && nama) {
    setNativeValue(namaInput, nama);
    log('Nama Bukti Dukung diisi:', nama);
    filledCount++;
    await sleep(150);
  }

  if (linkInput && link) {
    setNativeValue(linkInput, link);
    log('Link Bukti Dukung diisi:', link);
    filledCount++;
    await sleep(150);
  }

  if (filledCount === 0) {
    return { error: 'Tidak dapat menemukan kolom Nama atau Link di dalam modal Bukti Dukung.' };
  }

  return { success: true, filled: { nama, link } };
}

// ──────────────────────────────────────────────
// AUTO-FILL: REALISASI & SUMBER DATA
// ──────────────────────────────────────────────

async function fillRealisasi({ realisasi, sumberData }) {
  // 1. Cari modal Realisasi yang sedang aktif
  const modalSelectors = [
    '.modal.show',
    '.modal[style*="display: block"]',
    '[role="dialog"]:not([aria-hidden="true"])',
    '.swal2-modal',
  ];

  let modal = null;
  for (const sel of modalSelectors) {
    modal = document.querySelector(sel);
    if (modal) break;
  }

  if (!modal) {
    try {
      modal = await waitForElement('.modal.show, [role="dialog"]:not([aria-hidden="true"])', 4000);
    } catch {
      return {
        error: 'Modal Realisasi belum terbuka di halaman e-Kinerja. Silakan klik tombol "Edit" pada kolom Realisasi terlebih dahulu.',
      };
    }
  }

  log('Modal Realisasi aktif:', modal);

  const allInputs = [
    ...modal.querySelectorAll(
      'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]), textarea'
    ),
  ];

  let realisasiInput = null;
  let sumberInput = null;

  // Metode A: Cek berdasarkan teks label
  const labels = [...modal.querySelectorAll('label, .form-label, strong, span, p')];
  for (const label of labels) {
    const lText = label.textContent.trim().toUpperCase();
    const parent = label.closest('.form-group, .mb-3, .form-row, .row, div');
    const input = parent?.querySelector('input:not([type="hidden"]), textarea');

    if (input) {
      if (lText.includes('REALISASI') || lText.includes('CAPAIAN')) {
        realisasiInput = input;
      } else if (lText.includes('SUMBER DATA') || lText.includes('SUMBER')) {
        sumberInput = input;
      }
    }
  }

  // Metode B: Fallback berdasarkan urutan input modal e-Kinerja:
  // Input 0 = REALISASI
  // Input 1 = SUMBER DATA
  if (!realisasiInput && allInputs.length > 0) realisasiInput = allInputs[0];
  if (!sumberInput && allInputs.length > 1) sumberInput = allInputs[1];

  let filledCount = 0;

  if (realisasiInput && realisasi) {
    setNativeValue(realisasiInput, realisasi);
    log('Realisasi diisi:', realisasi);
    filledCount++;
    await sleep(150);
  }

  // Sumber data selalu diisi sama dengan Nama Bukti Dukung
  if (sumberInput && sumberData) {
    setNativeValue(sumberInput, sumberData);
    log('Sumber Data diisi:', sumberData);
    filledCount++;
    await sleep(150);
  }

  if (filledCount === 0) {
    return { error: 'Tidak dapat menemukan kolom Realisasi atau Sumber Data di dalam modal.' };
  }

  return { success: true, filled: { realisasi, sumberData } };
}

// ──────────────────────────────────────────────
// OBSERVER & MESSAGE LISTENER
// ──────────────────────────────────────────────

function initModalObserver() {
  const observer = new MutationObserver(() => {
    const modal = document.querySelector('.modal.show, [role="dialog"]:not([aria-hidden="true"])');
    if (modal) {
      chrome.runtime.sendMessage({
        type: 'MODAL_STATUS',
        payload: { open: true, timestamp: Date.now() },
      }).catch(() => {});
    }
  });

  observer.observe(document.body, { childList: true, subtree: true, attributes: true });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { type, payload } = message;

  switch (type) {
    case 'DETECT_RHK': {
      const rhkList = detectRHK();
      log('Hasil deteksi RHK:', rhkList);
      sendResponse({ rhkList });
      break;
    }

    case 'FILL_BUKTI_DUKUNG': {
      fillBuktiDukung(payload).then(sendResponse);
      return true;
    }

    case 'FILL_REALISASI': {
      fillRealisasi(payload).then(sendResponse);
      return true;
    }

    case 'PING': {
      sendResponse({ alive: true });
      break;
    }

    default:
      break;
  }
});

log('Content script e-Kinerja siap di:', window.location.href);
initModalObserver();
