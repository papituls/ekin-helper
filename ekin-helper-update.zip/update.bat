@echo off
setlocal enabledelayedexpansion
title Update Asisten e-Kinerja Helper

echo ========================================================
echo        PEMBARUAN ASISTEN E-KINERJA HELPER
echo ========================================================
echo.

:: 1. Tentukan target folder ekstensi (tempat file update.bat ini berada)
set "TARGET_DIR=%~dp0"
if "%TARGET_DIR:~-1%"=="\" set "TARGET_DIR=%TARGET_DIR:~0,-1%"

echo [1/3] Memeriksa file pembaruan di folder Downloads...
set "ZIP_FILE="
set "DOWNLOADS_DIR=%USERPROFILE%\Downloads"

:: Cari file ZIP pembaruan terbaru di Downloads
for /f "delims=" %%F in ('dir /b /o-d "%DOWNLOADS_DIR%\ekin*update*.zip" "%DOWNLOADS_DIR%\ekin*helper*.zip" "%DOWNLOADS_DIR%\ekin*.zip" 2^>nul') do (
    if not defined ZIP_FILE (
        set "ZIP_FILE=%DOWNLOADS_DIR%\%%F"
    )
)

:: Jika tidak ditemukan otomatis di Downloads, buka jendela Browse File GUI
if not defined ZIP_FILE (
    echo File zip pembaruan tidak ditemukan otomatis di folder Downloads.
    echo Membuka jendela pemilihan file manual...
    for /f "delims=" %%I in ('powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $dlg = New-Object System.Windows.Forms.OpenFileDialog; $dlg.Filter = 'File ZIP Pembaruan (*.zip)|*.zip|Semua File (*.*)|*.*'; $dlg.Title = 'Pilih File ZIP Pembaruan e-Kinerja'; if($dlg.ShowDialog() -eq 'OK'){ $dlg.FileName }"') do (
        set "ZIP_FILE=%%I"
    )
)

:: Jika user batal / tidak memilih file
if not defined ZIP_FILE (
    echo.
    echo [BATAL] Pembaruan dibatalkan. Tidak ada file ZIP yang dipilih.
    echo.
    pause
    exit /b 0
)

echo.
echo File pembaruan ditemukan:
echo "!ZIP_FILE!"
echo.
echo [2/3] Mengekstrak dan menimpa file ekstensi...
echo Lokasi target: "%TARGET_DIR%"
echo.

:: 2. Ekstrak pintar via PowerShell (menangani file flat maupun yang terbungkus subfolder)
powershell -NoProfile -Command ^
    "$zip = '!ZIP_FILE!';" ^
    "$target = '%TARGET_DIR%';" ^
    "$tempDir = Join-Path $env:TEMP ('ekin_upd_' + [Guid]::NewGuid().ToString().Substring(0,8));" ^
    "Expand-Archive -Path $zip -DestinationPath $tempDir -Force;" ^
    "$hasManifest = Test-Path (Join-Path $tempDir 'manifest.json');" ^
    "if ($hasManifest) {" ^
    "    Copy-Item -Path (Join-Path $tempDir '*') -Destination $target -Recurse -Force;" ^
    "} else {" ^
    "    $sub = Get-ChildItem -Path $tempDir -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'manifest.json') } | Select-Object -First 1;" ^
    "    if ($sub) {" ^
    "        Copy-Item -Path (Join-Path $sub.FullName '*') -Destination $target -Recurse -Force;" ^
    "    } else {" ^
    "        Copy-Item -Path (Join-Path $tempDir '*') -Destination $target -Recurse -Force;" ^
    "    }" ^
    "};" ^
    "Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue;"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [GAGAL] Terjadi kesalahan saat mengekstrak file.
    echo Pastikan file tidak sedang digunakan aplikasi lain.
    echo.
    pause
    exit /b 1
)

echo [3/3] Pembaruan selesai diterapkan dengan sukses!
echo.

:: 3. Tampilkan pesan berhasil resmi Windows
powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('Pembaruan Asisten e-Kinerja berhasil dipasang!`n`nSilakan buka chrome://extensions lalu klik tombol Refresh (Putar) pada ekstensi Asisten e-Kinerja, atau cukup restart Google Chrome.', 'Pembaruan Berhasil', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)"

exit /b 0
